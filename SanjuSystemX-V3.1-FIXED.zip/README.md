# SanjuSystemX V3.1 (Game Space)

Shizuku-powered Game Space. Package `com.sanju.systemx`. Intro (Itachi/Mangekyo), SFX, landscape HUD and restore journal are unchanged from V3.

## Build
- GitHub: push to `main` -> Actions -> *Build SanjuSystemX APK* -> download the artifact.
- Local: `gradle :app:assembleDebug` (or `./gradlew :app:assembleDebug` after `gradle wrapper --gradle-version 8.9`).
- Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Pipeline
DETECT -> APPLY -> VERIFY -> MONITOR -> ADJUST -> RESTORE, run by `engine/Engine.kt` ("SANJU AUTO GAME MODE").
Games are `GameProfile`s (`game/GameProfile.kt`); MLBB is built in, other games can be added from the GAME page.

## What each feature really does
| Feature | Backend | Verification | Honest limits |
|---|---|---|---|
| Shizuku | `shizuku/ShizukuBridge.kt`: binder/permission listeners, structured `CommandResult` (exit, stdout, stderr, duration, timeout) | live state | one failed command never marks Shizuku unsupported |
| Game detection | foreground package via `dumpsys` matched against all profiles | per-tick | needs Shizuku |
| Refresh rate | `min/peak_refresh_rate` (+ vendor keys only if they already exist) | polls the real panel (`Display.refreshRate`) | a 60 Hz panel is reported UNSUPPORTED; ignored requests show FAILED |
| Game FPS target | auto from panel: 60->30, 90->60, 120->90; `cmd game set --mode performance --fps N` on Android 13+ | actual FPS measured separately | a hint/cap; cannot raise a game's internal limit |
| FPS monitor | SurfaceFlinger `--latency` per layer, fallback `gfxinfo framestats` | de-duplicated real frame timestamps: FPS, average, 1% low, frame time, jank | `--` when no source gives data |
| GPU | devfreq `min_freq` floor chosen from the device's own `available_frequencies` (Balanced / Performance / Maximum best-effort) | read back from kernel | usually read-only for the shell user: then UNSUPPORTED, monitoring only |
| CPU | capability probe + PowerManager fixed-performance hint (`cmd power`) | confirmed only if the dump shows it, else APPLIED | no cpufreq/governor writes |
| Thermal | battery + thermal zones + `thermalservice`; NORMAL -> PERFORMANCE -> WARNING -> PROTECTION with hysteresis | live | PROTECTION releases GPU floor and CPU hint |
| Effects | SurfaceFlinger colour matrix (COOL/VIVID/CINEMATIC), animation scale (PERFORMANCE), DEFAULT restores | SF state change when readable, else APPLIED | display-wide, not the game's engine; Night Light shares the transform |
| Touch | system touch-and-hold delay (`secure long_press_timeout`) | read back | does NOT change hardware touch latency; vendor keys are listed, never written |
| Network | ping/jitter/loss via ICMP (TCP fallback), DNS lookup time; DNS via Private DNS (DoT) | `LinkProperties.isPrivateDnsActive` + server name | DNS does not lower in-match ping; some networks block port 853 |
| Background | `am kill` on unprotected user apps only, whitelist | before/after process count | nothing persistent changes |
| Restore | journal written before every change; also recovers after crash, reconnect and app restart | read-back per item | failed items stay in the journal and retry |
