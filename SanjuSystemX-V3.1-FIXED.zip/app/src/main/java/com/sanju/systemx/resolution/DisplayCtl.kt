package com.sanju.systemx.resolution

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import com.sanju.systemx.core.Features
import com.sanju.systemx.core.St
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.optimizer.Sett
import com.sanju.systemx.settings.Prefs

class ModeInfo(val id: Int, val w: Int, val h: Int, val hz: Float)

/** Reads the real display state from Android and requests (never assumes) a higher refresh rate. */
object DisplayCtl {
    private fun disp(ctx: Context): Display? = try {
        (ctx.applicationContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
    } catch (t: Throwable) { null }

    /** Refresh rate of the active display mode in Hz, or -1 if unreadable. */
    fun current(ctx: Context): Float = try { disp(ctx)?.refreshRate ?: -1f } catch (t: Throwable) { -1f }

    fun modes(ctx: Context): List<ModeInfo> = try {
        disp(ctx)?.supportedModes?.map { ModeInfo(it.modeId, it.physicalWidth, it.physicalHeight, it.refreshRate) } ?: emptyList()
    } catch (t: Throwable) { emptyList() }

    fun activeMode(ctx: Context): ModeInfo? = try {
        disp(ctx)?.mode?.let { ModeInfo(it.modeId, it.physicalWidth, it.physicalHeight, it.refreshRate) }
    } catch (t: Throwable) { null }

    /** Distinct refresh rates the panel reports, ascending. */
    fun rates(ctx: Context): List<Int> = modes(ctx).map { Math.round(it.hz) }.distinct().sorted()

    /** Highest refresh rate available at the active resolution (falls back to any resolution). */
    fun maxRate(ctx: Context): Int {
        val act = activeMode(ctx)
        val all = modes(ctx)
        val same = if (act != null) all.filter { it.w == act.w && it.h == act.h } else emptyList()
        val pool = if (same.isNotEmpty()) same else all
        return pool.maxOfOrNull { Math.round(it.hz) } ?: -1
    }

    fun minRate(ctx: Context): Int = rates(ctx).minOrNull() ?: -1

    fun resolution(ctx: Context): String = activeMode(ctx)?.let { "${it.w}x${it.h}" } ?: "--"

    fun describeActive(ctx: Context): String =
        activeMode(ctx)?.let { "mode #${it.id}  ${it.w}x${it.h} @ ${Math.round(it.hz)} Hz" } ?: "--"

    // ---------------------------------------------------------------- request / verify

    /** Settings keys that exist on this device and steer the refresh rate. Vendor keys are used only if they already exist. */
    private val AOSP = listOf("min_refresh_rate", "peak_refresh_rate")
    private val VENDOR_INT = listOf("user_refresh_rate", "miui_refresh_rate")

    class Request(val targetHz: Int, val state: St, val detail: String)

    /**
     * DETECT -> REQUEST. Returns UNSUPPORTED when the panel only offers one rate, REQUESTED when the settings were
     * written and read back, FAILED otherwise. Verification against the real display happens in [verify].
     */
    fun request(ctx: Context, prefs: Prefs): Request {
        val max = maxRate(ctx)
        val cur = Math.round(current(ctx))
        if (max <= 0) return Request(0, St.UNSUPPORTED, "Cannot read display modes")
        if (max <= 60 && rates(ctx).size <= 1) return Request(max, St.UNSUPPORTED, "This panel reports only $max Hz. A physical panel cannot exceed its hardware rate")
        val v = max.toString() + ".0"
        var wrote = 0
        for (k in AOSP) if (Sett.putVerified(prefs, "system", k, v)) wrote++
        for (k in VENDOR_INT) {
            if (Sett.get("system", k) != "null" || Sett.get("secure", k) != "null") {
                val ns = if (Sett.get("system", k) != "null") "system" else "secure"
                if (Sett.putVerified(prefs, ns, k, max.toString())) wrote++
            }
        }
        return if (wrote == 0) Request(max, St.FAILED, "Android refused every refresh-rate setting")
        else Request(max, St.REQUESTED, "Requested $max Hz (display was $cur Hz)")
    }

    /** Polls the real display for up to ~3 s. VERIFIED only if the active mode actually reaches the target. */
    fun verify(ctx: Context, target: Int): Pair<St, String> {
        var best = -1f
        for (i in 0 until 6) {
            val c = current(ctx)
            if (c > best) best = c
            if (c >= target - 1.5f) return St.VERIFIED to "Display is running at ${Math.round(c)} Hz"
            try { Thread.sleep(500) } catch (e: InterruptedException) { break }
        }
        return St.FAILED to "Requested $target Hz but the display stayed at ${Math.round(best)} Hz. Android/vendor ignored the request"
    }

    fun setStatus(st: St, detail: String) = Features.set(Features.DISPLAY, st, detail)
}
