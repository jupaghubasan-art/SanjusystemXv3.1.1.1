package com.sanju.systemx.core

import android.content.Context
import android.os.Build
import com.sanju.systemx.cpu.CpuEngine
import com.sanju.systemx.cpu.CpuInfo
import com.sanju.systemx.gpu.GpuEngine
import com.sanju.systemx.gpu.GpuInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState

/** Centralised DETECT step. The UI and the engine decide what to offer from [Caps], never from a device name. */
object CapabilityEngine {
    @Volatile var gpu: GpuInfo? = null
    @Volatile var cpu: CpuInfo? = null
    @Volatile var detected = false
    @Volatile var vendorTouchKeys: List<String> = emptyList()
    @Volatile var socLabel = ""

    private val PROBE = """
echo "@@CMDL"; cmd -l 2>/dev/null
echo "@@PING"; command -v ping 2>/dev/null
echo "@@SF"; service check SurfaceFlinger 2>/dev/null
echo "@@SET"
for k in min_refresh_rate peak_refresh_rate; do echo "system.§k=§(settings get system §k 2>/dev/null)"; done
echo "global.private_dns_mode=§(settings get global private_dns_mode 2>/dev/null)"
echo "secure.long_press_timeout=§(settings get secure long_press_timeout 2>/dev/null)"
echo "@@VTOUCH"; settings list system 2>/dev/null | grep -i -E 'touch|game' | head -n 8
echo "@@THERM"; dumpsys thermalservice 2>/dev/null | grep -m1 -i 'Thermal Status'
echo "@@END"
""".replace('§', '$')

    private fun sections(out: String): Map<String, List<String>> {
        val m = HashMap<String, MutableList<String>>()
        var cur = ""
        for (raw in out.lines()) {
            val l = raw.trim()
            if (l.startsWith("@@")) { cur = l.substring(2); m[cur] = ArrayList(); continue }
            if (l.isNotEmpty()) m[cur]?.add(l)
        }
        return m
    }

    fun detect(ctx: Context, fpsVerified: Boolean) {
        val out = ArrayList<Capability>()
        val st = ShizukuBridge.state()
        out.add(Capability(Cap.SHIZUKU, st != ShizukuState.UNSUPPORTED, st == ShizukuState.CONNECTED, st == ShizukuState.CONNECTED,
            if (st == ShizukuState.CONNECTED) "Running as " + ShizukuBridge.privilegeLabel() else st.name, "Shizuku"))
        if (st != ShizukuState.CONNECTED) { Caps.list = out; return }

        val r = ShizukuBridge.sh(PROBE, 14000L, "DETECT")
        val sec = sections(r.stdout)
        val cmdl = sec["CMDL"] ?: emptyList()
        val set = HashMap<String, String>()
        for (l in sec["SET"] ?: emptyList()) { val i = l.indexOf('='); if (i > 0) set[l.substring(0, i)] = l.substring(i + 1) }
        val sdk = Build.VERSION.SDK_INT
        socLabel = (if (sdk >= 31) Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL else Build.HARDWARE) + " / " + Build.MANUFACTURER

        // Display
        val maxHz = DisplayCtl.maxRate(ctx)
        val keysOk = set["system.min_refresh_rate"] != null
        out.add(Capability(Cap.DISPLAY_HIGH_HZ, maxHz > 60, maxHz > 60 && keysOk, false,
            if (maxHz <= 0) "Cannot read display modes" else if (maxHz <= 60) "Panel reports only $maxHz Hz" else "Panel offers up to $maxHz Hz",
            "settings min/peak_refresh_rate"))

        // Game mode
        val gm = sdk >= 31 && cmdl.any { it == "game" }
        out.add(Capability(Cap.GAME_MODE, gm, gm, false, if (gm) "GameManager available" else "Needs Android 12+ with the game service", "cmd game"))
        out.add(Capability(Cap.GAME_FPS, gm && sdk >= 33, gm && sdk >= 33, false,
            if (sdk >= 33 && gm) "FPS intervention flag available (a cap/hint, cannot raise a game's own limit)" else "Needs Android 13+", "cmd game set --fps"))

        // GPU / CPU
        val g = GpuEngine.probe(); gpu = g
        out.add(Capability(Cap.GPU_MON, g != null && (g.curF > 0 || g.busySources.isNotEmpty()), false, false,
            if (g == null) "No readable GPU interface" else g.vendor + (if (g.renderer.isNotEmpty()) " (" + g.renderer.take(40) + ")" else ""), "devfreq / kgsl"))
        out.add(Capability(Cap.GPU_PERF, g?.controllable == true, g?.controllable == true, false,
            when {
                g == null || g.dir.isEmpty() -> "No GPU frequency interface"
                !g.writableMin -> "GPU frequency node is read-only for the shell user"
                g.usable.size < 2 -> "Fewer than 2 frequency steps exposed"
                else -> g.usable.size.toString() + " steps, " + GpuEngine.toMhz(g.usable.first()) + "-" + GpuEngine.toMhz(g.usable.last()) + " MHz"
            }, "devfreq min_freq"))
        val c = CpuEngine.probe(); cpu = c
        out.add(Capability(Cap.CPU_MON, true, false, false, CpuEngine.describe(c), "/proc/stat, cpufreq"))
        out.add(Capability(Cap.CPU_PERF, c.fixedPerfCommand, c.fixedPerfCommand, false,
            if (c.fixedPerfCommand) "PowerManager fixed-performance hint (HAL dependent)" else "Not available on this Android version", "cmd power"))

        // Thermal
        val tl = sec["THERM"]?.firstOrNull()
        out.add(Capability(Cap.THERMAL, true, false, true, "Battery + thermal zones" + (if (tl != null) " + thermal service" else ""), "thermal_zone, thermalservice"))

        // Touch
        vendorTouchKeys = sec["VTOUCH"] ?: emptyList()
        val lp = set["secure.long_press_timeout"] != null
        out.add(Capability(Cap.TOUCH, lp, lp, false,
            "Touch-and-hold delay only. Android exposes no touch-latency control" +
                (if (vendorTouchKeys.isNotEmpty()) ". Vendor keys seen but not modified: " + vendorTouchKeys.size else ""), "secure long_press_timeout"))

        // Colour
        val sf = (sec["SF"] ?: emptyList()).any { it.contains("found") }
        out.add(Capability(Cap.COLOR, sf, sf, false, if (sf) "SurfaceFlinger colour transform reachable" else "SurfaceFlinger not reachable", "SurfaceFlinger 1015"))

        // Network
        val dns = sdk >= 28 && set["global.private_dns_mode"] != null
        out.add(Capability(Cap.DNS, dns, dns, false, if (dns) "Private DNS (DoT), verified via LinkProperties" else "Needs Android 9+", "settings private_dns_*"))
        val ping = (sec["PING"] ?: emptyList()).isNotEmpty()
        out.add(Capability(Cap.PING, true, false, true, if (ping) "ICMP ping" else "TCP connect time (no ping binary)", if (ping) "ping" else "socket"))

        out.add(Capability(Cap.FPS_MON, true, false, fpsVerified, if (fpsVerified) "Frame data received" else "Verified when a game is running", "SurfaceFlinger --latency / gfxinfo"))
        out.add(Capability(Cap.BG, true, true, false, "am kill on unprotected user apps only", "pm / am"))

        // verified flags that were proven at runtime are folded in by the engine through Features
        Caps.list = out
        detected = true
    }
}
