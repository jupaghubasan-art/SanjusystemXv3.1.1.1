package com.sanju.systemx

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import com.sanju.systemx.engine.Engine
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.sfx.SfxHub
import com.sanju.systemx.sfx.SfxPlayer
import com.sanju.systemx.ui.Hud
import com.sanju.systemx.ui.IntroView
import com.sanju.systemx.ui.Pal

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private var sfx: SfxPlayer? = null
    private var hud: Hud? = null
    private var intro: IntroView? = null
    private lateinit var root: FrameLayout
    private val ui = Handler(Looper.getMainLooper())
    private var askedShizuku = false

    private val uiTick = object : Runnable {
        override fun run() {
            hud?.update()
            ui.postDelayed(this, 250L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        Pal.haptic = prefs.getB("haptic", true)
        sfx = SfxPlayer(this, prefs).also { SfxHub.bind(it) }

        // Start Shizuku/system initialisation immediately. The intro never waits for it.
        Engine.init(this)
        Engine.kick()

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        root = FrameLayout(this)
        root.setBackgroundColor(Pal.BG)
        val h = Hud(this, prefs)
        hud = h
        root.addView(h.view, FrameLayout.LayoutParams(-1, -1))
        if (savedInstanceState == null) {
            val iv = IntroView(this) { onIntroDone() }
            intro = iv
            root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        }
        setContentView(root)
        sfx?.attachHaptics(root)
        hideSystemBars()
        if (prefs.getB("watcher", true)) h.startWatcher()
        intro?.let { iv -> root.post { iv.start() } }
    }

    private fun onIntroDone() {
        val iv = intro ?: return
        intro = null
        iv.animate().alpha(0f).setDuration(250L).withEndAction { root.removeView(iv) }.start()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        } else {
            askShizukuOnce()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        askShizukuOnce()
    }

    private fun askShizukuOnce() {
        if (askedShizuku) return
        askedShizuku = true
        if (Engine.shizuku == ShizukuState.PERMISSION_REQUIRED || ShizukuBridge.state() == ShizukuState.PERMISSION_REQUIRED) {
            ShizukuBridge.requestPermission()
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        Engine.uiVisible = true
        Engine.kick()
        ui.post(uiTick)
        if (intro == null) askShizukuOnce()
    }

    override fun onPause() {
        Engine.uiVisible = false
        ui.removeCallbacks(uiTick)
        super.onPause()
    }

    override fun onDestroy() {
        intro = null
        sfx?.let { SfxHub.unbind(it); it.release() }
        sfx = null
        super.onDestroy()
    }
}
