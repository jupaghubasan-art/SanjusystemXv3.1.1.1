package com.sanju.systemx.gpu

import com.sanju.systemx.core.St
import com.sanju.systemx.game.GpuLevel
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

/** What was actually found. Nothing here is assumed. */
class GpuInfo(
    val dir: String,
    val vendor: String,         // e.g. "Qualcomm Adreno", "ARM Mali", "unknown"
    val renderer: String,       // GLES renderer string if readable
    val writableMin: Boolean,
    val avail: List<Long>,      // available_frequencies (raw units of the node)
    val minF: Long, val maxF: Long, val curF: Long,
    val governor: String,
    val busySources: List<String>
) {
    /** Steps the device exposes that are at or below the device's own max_freq cap. */
    val usable: List<Long> get() = avail.filter { maxF <= 0 || it <= maxF }.sorted()
    val controllable: Boolean get() = writableMin && usable.size >= 2
}

object GpuEngine {
    class Result(val st: St, val detail: String)

    fun toMhz(v: Long): Int = when {
        v >= 1_000_000L -> (v / 1_000_000L).toInt()
        v >= 1_000L -> (v / 1_000L).toInt()
        else -> v.toInt()
    }

    private fun vendorFrom(renderer: String, dir: String): String {
        val s = (renderer + " " + dir).lowercase()
        return when {
            s.contains("adreno") || s.contains("kgsl") -> "Qualcomm Adreno"
            s.contains("mali") -> "ARM Mali"
            s.contains("powervr") || s.contains("img") -> "Imagination PowerVR"
            s.contains("xclipse") -> "Samsung Xclipse"
            else -> "unknown"
        }
    }

    /** DETECT: finds the GPU devfreq node (read-only discovery; nothing is written). */
    fun probe(): GpuInfo? {
        val script = """
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*; do
  [ -r "§d/cur_freq" ] || continue
  case "§d" in *kgsl*|*gpu*|*mali*|*GPU*|*Mali*|*g3d*) ;; *) continue ;; esac
  echo "DIR=§d"
  if [ -w "§d/min_freq" ]; then echo "WMIN=1"; fi
  echo "AVAIL=§(cat "§d/available_frequencies" 2>/dev/null)"
  echo "MIN=§(cat "§d/min_freq" 2>/dev/null)"
  echo "MAX=§(cat "§d/max_freq" 2>/dev/null)"
  echo "CUR=§(cat "§d/cur_freq" 2>/dev/null)"
  echo "GOV=§(cat "§d/governor" 2>/dev/null)"
  [ -r "§d/load" ] && echo "BUSY=§d/load"
  break
done
[ -r /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage ] && echo "BUSY=/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage"
[ -r /sys/class/kgsl/kgsl-3d0/gpubusy ] && echo "BUSY=/sys/class/kgsl/kgsl-3d0/gpubusy"
[ -r /sys/kernel/gpu/gpu_busy ] && echo "BUSY=/sys/kernel/gpu/gpu_busy"
echo "GL=§(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES:')"
""".replace('§', '$')
        val r = ShizukuBridge.sh(script, 9000L, "GPU_PROBE")
        var dir = ""; var wmin = false; var gl = ""; var gov = ""
        var avail: List<Long> = emptyList()
        var minF = -1L; var maxF = -1L; var curF = -1L
        val busy = ArrayList<String>()
        for (l in r.stdout.lines()) {
            val i = l.indexOf('=')
            if (i <= 0) continue
            val k = l.substring(0, i); val v = l.substring(i + 1).trim()
            when (k) {
                "DIR" -> dir = v
                "WMIN" -> wmin = true
                "AVAIL" -> avail = v.split(' ', '\t').mapNotNull { it.toLongOrNull() }.sorted()
                "MIN" -> minF = v.toLongOrNull() ?: -1L
                "MAX" -> maxF = v.toLongOrNull() ?: -1L
                "CUR" -> curF = v.toLongOrNull() ?: -1L
                "GOV" -> gov = v
                "BUSY" -> busy.add(v)
                "GL" -> gl = v
            }
        }
        if (dir.isEmpty() && busy.isEmpty() && gl.isEmpty()) return null
        return GpuInfo(dir, vendorFrom(gl, dir), gl.removePrefix("GLES:").trim(), wmin, avail, minF, maxF, curF, gov, busy)
    }

    /** Picks a REAL step exposed by the device for the requested level. Never invents a frequency. */
    fun pick(info: GpuInfo, level: GpuLevel): Long? {
        val u = info.usable
        if (u.size < 2) return null
        return when (level) {
            GpuLevel.BALANCED -> u[u.size / 2]
            GpuLevel.PERFORMANCE -> u[maxOf(0, u.size - 2)]
            GpuLevel.MAXIMUM, GpuLevel.AUTO -> u[u.size - 1]
        }
    }

    /** APPLY -> READ BACK -> VERIFY. Raises only the devfreq minimum floor, never touches max or voltage. */
    fun apply(prefs: Prefs, info: GpuInfo, level: GpuLevel): Result {
        if (info.dir.isEmpty()) return Result(St.UNSUPPORTED, "No GPU frequency interface on this device")
        if (!info.writableMin) return Result(St.UNSUPPORTED, "GPU frequency node is read-only for the shell user")
        val target = pick(info, level) ?: return Result(St.UNSUPPORTED, "Device exposes fewer than 2 GPU frequency steps")
        Journal.saveOnce(prefs, "gpu.min", info.dir + "|" + info.minF)
        ShizukuBridge.sh("echo $target > ${info.dir}/min_freq", 4000L, "GPU_PERFORMANCE")
        val back = ShizukuBridge.sh("cat ${info.dir}/min_freq", 3000L, "GPU_PERFORMANCE").stdout.trim().toLongOrNull()
        return if (back == target) Result(St.VERIFIED, "GPU floor ${toMhz(target)} MHz (read back from kernel)")
        else Result(St.FAILED, "Kernel refused the GPU floor (read back " + (back?.let { toMhz(it).toString() + " MHz" } ?: "nothing") + ")")
    }

    /** Puts the original min_freq back (used on exit and by thermal protection). */
    fun release(prefs: Prefs): Boolean {
        val v = Journal.load(prefs)["gpu.min"] ?: return true
        val p = v.split('|')
        if (p.size != 2 || p[1].toLongOrNull() == null || p[1].toLong() <= 0L) return true
        val ok = ShizukuBridge.sh("echo ${p[1]} > ${p[0]}/min_freq", 4000L, "GPU_PERFORMANCE").success
        val back = ShizukuBridge.sh("cat ${p[0]}/min_freq", 3000L, "GPU_PERFORMANCE").stdout.trim().toLongOrNull()
        return ok && back == p[1].toLong()
    }
}
