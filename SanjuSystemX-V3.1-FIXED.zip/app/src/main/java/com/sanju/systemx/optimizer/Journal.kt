package com.sanju.systemx.optimizer

import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

/**
 * Restore journal. Every original value is written (synchronously) BEFORE anything is changed, so a crash,
 * a Shizuku disconnect or an app restart can always be recovered from. Keys:
 *   set.<ns>.<key> = original value of a settings key ("null" = was unset)
 *   gpu.min        = <dir>|<original min_freq>
 *   game.<pkg>     = 1 (game mode was changed, restore = reset)
 *   power.fixed    = 0 (fixed performance mode was enabled, restore = disable)
 *   fx.color       = 1 (SurfaceFlinger colour transform was set, restore = disable)
 * Legacy V3 keys are still understood.
 */
object Journal {
    private const val KEY = "journal"

    fun load(prefs: Prefs): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in prefs.getS(KEY, "").lines()) {
            val i = l.indexOf('=')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        return m
    }

    fun save(prefs: Prefs, m: Map<String, String>) {
        prefs.setSNow(KEY, m.entries.joinToString("\n") { it.key + "=" + it.value.replace('\n', ' ') })
    }

    fun hasEntries(prefs: Prefs): Boolean = load(prefs).isNotEmpty()

    fun saveOnce(prefs: Prefs, key: String, value: String) {
        val m = load(prefs)
        if (!m.containsKey(key)) { m[key] = value; save(prefs, m) }
    }

    fun size(prefs: Prefs): Int = load(prefs).size
}

/** Settings-provider access that always journals the original value first and reads the value back. */
object Sett {
    private val NS = setOf("system", "secure", "global")

    fun get(ns: String, key: String): String {
        if (ns !in NS || !key.matches(Regex("[A-Za-z0-9_.]+"))) return "null"
        val r = ShizukuBridge.sh("settings get $ns $key 2>/dev/null", 4000L, "SETTINGS")
        return r.stdout.trim().ifEmpty { "null" }
    }

    /** Returns true only if the value read back equals the requested value. */
    fun putVerified(prefs: Prefs, ns: String, key: String, value: String): Boolean {
        if (ns !in NS || !key.matches(Regex("[A-Za-z0-9_.]+")) || !value.matches(Regex("[A-Za-z0-9_.\\-]+"))) return false
        Journal.saveOnce(prefs, "set.$ns.$key", get(ns, key))
        val r = ShizukuBridge.sh("settings put $ns $key $value", 4000L, "SETTINGS")
        if (!r.success) return false
        return sameValue(get(ns, key), value)
    }

    fun restore(ns: String, key: String, original: String): Boolean {
        if (ns !in NS || !key.matches(Regex("[A-Za-z0-9_.]+"))) return true
        val cmd = if (original == "null") "settings delete $ns $key" else "settings put $ns $key $original"
        val r = ShizukuBridge.sh(cmd, 4000L, "SETTINGS")
        if (!r.success) return false
        return sameValue(get(ns, key), original)
    }

    private fun sameValue(a: String, b: String): Boolean {
        if (a == b) return true
        val x = a.toFloatOrNull(); val y = b.toFloatOrNull()
        return x != null && y != null && Math.abs(x - y) < 0.01f
    }
}
