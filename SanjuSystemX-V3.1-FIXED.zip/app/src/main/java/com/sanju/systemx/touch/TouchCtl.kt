package com.sanju.systemx.touch

import com.sanju.systemx.core.St
import com.sanju.systemx.game.TouchMode
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.optimizer.Sett
import com.sanju.systemx.settings.Prefs

/**
 * Honest touch backend. Android exposes NO setting that lowers hardware touch latency. The one real, verifiable
 * input-timing setting a shell can change is the system touch-and-hold delay (secure long_press_timeout), which
 * controls how fast Android recognises a press-and-hold. FAST / SLOW change exactly that value, verified by read-back.
 */
object TouchCtl {
    class Result(val st: St, val detail: String)

    private const val KEY = "long_press_timeout"

    fun valueFor(m: TouchMode): String? = when (m) { TouchMode.FAST -> "300"; TouchMode.SLOW -> "800"; TouchMode.DEFAULT -> null }

    fun current(): String = Sett.get("secure", KEY)

    fun apply(prefs: Prefs, m: TouchMode): Result {
        val v = valueFor(m)
        if (v == null) {
            val j = Journal.load(prefs)
            val orig = j["set.secure.$KEY"] ?: return Result(St.VERIFIED, "Default touch timing (nothing was changed)")
            val ok = Sett.restore("secure", KEY, orig)
            if (ok) { j.remove("set.secure.$KEY"); Journal.save(prefs, j) }
            return if (ok) Result(St.VERIFIED, "Touch-and-hold delay restored") else Result(St.FAILED, "Could not restore touch delay")
        }
        return if (Sett.putVerified(prefs, "secure", KEY, v)) Result(St.VERIFIED, "Touch-and-hold delay $v ms (read back). Does not change hardware touch latency")
        else Result(St.FAILED, "Android refused the touch timing setting")
    }
}
