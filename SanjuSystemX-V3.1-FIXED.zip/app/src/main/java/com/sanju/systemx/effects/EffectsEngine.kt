package com.sanju.systemx.effects

import com.sanju.systemx.core.St
import com.sanju.systemx.game.Effect
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.optimizer.Sett
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

class FxResult(val st: St, val detail: String)

/** One way of changing how the screen looks. Add a vendor backend by implementing this and listing it in [EffectsEngine.backends]. */
interface EffectBackend {
    val name: String
    fun detect(): Boolean
    fun apply(prefs: Prefs, e: Effect): FxResult
    fun restore(): Boolean
}

/**
 * SurfaceFlinger global colour transform (the same interface Android debug tools use, available to the shell user).
 * It changes how the whole display is presented. It does NOT modify the game's own graphics engine.
 * Night Light / colour correction use the same transform, so enabling them may override or be overridden by this.
 */
object SfColorBackend : EffectBackend {
    override val name = "SurfaceFlinger colour matrix"
    private const val RW = 0.2126f
    private const val GW = 0.7152f
    private const val BW = 0.0722f

    override fun detect(): Boolean =
        ShizukuBridge.sh("service check SurfaceFlinger 2>/dev/null", 3000L, "DISPLAY_COLOR").stdout.contains("found")

    /** Row-major 4x4 (rgb in, rgb out, translation in last column) -> column-major float list. */
    private fun matrix(sat: Float, r: Float, g: Float, b: Float, contrast: Float): FloatArray {
        val s = sat
        val m = arrayOf(
            floatArrayOf((1 - s) * RW + s, (1 - s) * GW, (1 - s) * BW),
            floatArrayOf((1 - s) * RW, (1 - s) * GW + s, (1 - s) * BW),
            floatArrayOf((1 - s) * RW, (1 - s) * GW, (1 - s) * BW + s)
        )
        val gain = floatArrayOf(r * contrast, g * contrast, b * contrast)
        val tr = (1f - contrast) / 2f
        val out = FloatArray(16)
        for (row in 0 until 3) for (col in 0 until 3) out[col * 4 + row] = m[row][col] * gain[row]
        out[12] = tr; out[13] = tr; out[14] = tr; out[15] = 1f
        return out
    }

    private fun matrixFor(e: Effect): FloatArray? = when (e) {
        Effect.COOL -> matrix(1.08f, 0.93f, 0.98f, 1.0f, 1.0f)
        Effect.VIVID -> matrix(1.35f, 1f, 1f, 1f, 1.02f)
        Effect.CINEMATIC -> matrix(0.92f, 1.0f, 0.97f, 0.90f, 1.06f)
        else -> null
    }

    private fun dump(): String =
        ShizukuBridge.sh("dumpsys SurfaceFlinger 2>/dev/null | grep -i -m6 -E 'color ?(matrix|transform)'", 6000L, "DISPLAY_COLOR").stdout

    override fun apply(prefs: Prefs, e: Effect): FxResult {
        val m = matrixFor(e) ?: return FxResult(St.UNSUPPORTED, "No colour matrix for this effect")
        Journal.saveOnce(prefs, "fx.color", "1")
        val before = dump()
        val args = m.joinToString(" ") { "f " + String.format(java.util.Locale.US, "%.4f", it) }
        val r = ShizukuBridge.sh("service call SurfaceFlinger 1015 i32 1 $args 2>&1", 4000L, "DISPLAY_COLOR")
        if (!r.success || !r.stdout.contains("Parcel(") || r.out.contains("Error", true))
            return FxResult(St.FAILED, "SurfaceFlinger rejected the colour transform")
        val after = dump()
        return if (after.isNotEmpty() && after != before) FxResult(St.VERIFIED, "SurfaceFlinger colour state changed")
        else FxResult(St.APPLIED, "Accepted by SurfaceFlinger (no read-back available on this build)")
    }

    override fun restore(): Boolean =
        ShizukuBridge.sh("service call SurfaceFlinger 1015 i32 0 2>&1", 4000L, "DISPLAY_COLOR").stdout.contains("Parcel(")
}

/** PERFORMANCE effect: shorter system animations (real settings, verified by read-back). Colours stay neutral. */
object AnimBackend : EffectBackend {
    override val name = "System animation scale"
    private val keys = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    override fun detect(): Boolean = true
    override fun apply(prefs: Prefs, e: Effect): FxResult {
        if (e != Effect.PERFORMANCE) return FxResult(St.UNSUPPORTED, "n/a")
        var ok = 0
        for (k in keys) if (Sett.putVerified(prefs, "global", k, "0.5")) ok++
        return if (ok == keys.size) FxResult(St.VERIFIED, "System animation scale 0.5x (read back)")
        else if (ok > 0) FxResult(St.APPLIED, "$ok of ${keys.size} animation settings changed")
        else FxResult(St.FAILED, "Android refused the animation settings")
    }
    override fun restore(): Boolean = true // the generic journal restores set.global.* keys
}

object EffectsEngine {
    val backends: List<EffectBackend> = listOf(SfColorBackend, AnimBackend)

    fun supported(): Boolean = SfColorBackend.detect()

    /** Applies [e]; first undoes any previous effect so effects never stack. */
    fun apply(prefs: Prefs, e: Effect): FxResult {
        if (e == Effect.DEFAULT) { restoreAll(prefs); return FxResult(St.VERIFIED, "Default colours") }
        restoreAll(prefs)
        return when (e) {
            Effect.PERFORMANCE -> AnimBackend.apply(prefs, e)
            else -> if (!SfColorBackend.detect()) FxResult(St.UNSUPPORTED, "SurfaceFlinger colour interface not reachable")
            else SfColorBackend.apply(prefs, e)
        }
    }

    fun restoreAll(prefs: Prefs) {
        val j = Journal.load(prefs)
        if (j.containsKey("fx.color")) {
            if (SfColorBackend.restore()) { j.remove("fx.color"); Journal.save(prefs, j) }
        }
        val j2 = Journal.load(prefs)
        var changed = false
        for ((k, v) in j2.entries.toList()) {
            if (k.startsWith("set.global.") && k.removePrefix("set.global.") in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
                if (Sett.restore("global", k.removePrefix("set.global."), v)) { j2.remove(k); changed = true }
            }
        }
        if (changed) Journal.save(prefs, j2)
    }
}
