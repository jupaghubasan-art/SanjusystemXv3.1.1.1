package com.sanju.systemx.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArrayList

enum class ShizukuState { CONNECTED, DISCONNECTED, PERMISSION_REQUIRED, UNSUPPORTED }

/** Structured result of one privileged command. Nothing is "successful" unless the process really exited 0. */
class CommandResult(
    val success: Boolean,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long,
    val capability: String,
    val errorReason: String
) {
    /** stdout + stderr, trimmed. Handy for parsing tools that print errors on stdout. */
    val out: String get() = (stdout + (if (stderr.isNotEmpty()) "\n" + stderr else "")).trim()
    val ok: Boolean get() = success
    val code: Int get() = exitCode
}

/**
 * The single centralized Shizuku execution layer. Every privileged operation in the app goes through exec()/sh().
 * Handles binder detection, permission, binder death/reconnect listeners, timeouts and stdout/stderr/exit code.
 * A single failed command never marks the whole system unsupported.
 */
object ShizukuBridge {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242

    /** Set only when the Shizuku client library itself lacks the shell entry point (a real version incompatibility). */
    @Volatile private var shellApiMissing = false
    @Volatile private var inited = false
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    private val onReceived = Shizuku.OnBinderReceivedListener { notifyChange() }
    private val onDead = Shizuku.OnBinderDeadListener { notifyChange() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> notifyChange() }

    /** Registers lifecycle listeners once. Safe to call repeatedly. */
    fun init() {
        if (inited) return
        inited = true
        try {
            Shizuku.addBinderReceivedListenerSticky(onReceived)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        } catch (t: Throwable) { inited = false }
    }

    /** Called (on the main thread) when the binder arrives, dies, or the permission result comes in. */
    fun addStateListener(l: () -> Unit) { listeners.add(l) }

    private fun notifyChange() { for (l in listeners) try { l() } catch (t: Throwable) { } }

    fun isInstalled(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (t: Throwable) { false }

    fun state(): ShizukuState {
        if (shellApiMissing) return ShizukuState.UNSUPPORTED
        return try {
            if (Shizuku.isPreV11()) ShizukuState.UNSUPPORTED
            else if (!Shizuku.pingBinder()) ShizukuState.DISCONNECTED
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) ShizukuState.CONNECTED
            else ShizukuState.PERMISSION_REQUIRED
        } catch (t: Throwable) {
            ShizukuState.DISCONNECTED
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.isPreV11() || !Shizuku.pingBinder()) return
            if (Shizuku.shouldShowRequestPermissionRationale()) return // user chose "deny and don't ask again"
            Shizuku.requestPermission(REQ)
        } catch (t: Throwable) { }
    }

    /** "root" when Shizuku runs as root, "adb shell" for uid 2000, otherwise the raw uid. */
    fun privilegeLabel(): String = try {
        when (val u = Shizuku.getUid()) { 0 -> "root"; 2000 -> "adb shell"; else -> "uid $u" }
    } catch (t: Throwable) { "unknown" }

    private val newProcessMethod by lazy {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        m
    }

    private fun fail(code: Int, why: String, cap: String, t0: Long) =
        CommandResult(false, code, "", why, System.currentTimeMillis() - t0, cap, why)

    private class Pump(private val ins: java.io.InputStream) : Thread() {
        val buf = ByteArrayOutputStream()
        init { isDaemon = true }
        override fun run() {
            try {
                val b = ByteArray(4096)
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    if (buf.size() < 512 * 1024) buf.write(b, 0, n)
                }
            } catch (t: Throwable) { }
        }
        fun text(): String = try { buf.toString("UTF-8") } catch (t: Throwable) { "" }
    }

    /** Runs a command with shell privileges through Shizuku. Never throws. */
    fun exec(cmd: Array<String>, timeoutMs: Long = 5000L, capability: String = ""): CommandResult {
        val t0 = System.currentTimeMillis()
        val st = state()
        if (st != ShizukuState.CONNECTED) return fail(-2, "SHIZUKU REQUIRED ($st)", capability, t0)
        var proc: Process? = null
        try {
            val p = newProcessMethod.invoke(null, cmd, null, null) as Process
            proc = p
            val so = Pump(p.inputStream); val se = Pump(p.errorStream)
            so.start(); se.start()
            val deadline = t0 + timeoutMs
            var code = -1
            var timedOut = false
            while (true) {
                try { code = p.exitValue(); break } catch (e: IllegalThreadStateException) { }
                if (System.currentTimeMillis() >= deadline) { timedOut = true; break }
                try { Thread.sleep(12) } catch (e: InterruptedException) { timedOut = true; break }
            }
            if (timedOut) { try { p.destroy() } catch (t: Throwable) { } }
            so.join(400); se.join(400)
            val dur = System.currentTimeMillis() - t0
            val o = so.text().trim(); val e = se.text().trim()
            return if (timedOut) CommandResult(false, -4, o, e, dur, capability, "TIMEOUT after ${timeoutMs}ms")
            else CommandResult(code == 0, code, o, e, dur, capability, if (code == 0) "" else (e.ifEmpty { "exit code $code" }))
        } catch (e: NoSuchMethodException) {
            shellApiMissing = true
            return fail(-3, "UNSUPPORTED: this Shizuku client has no shell API", capability, t0)
        } catch (t: Throwable) {
            return fail(-1, "SHELL ERROR: " + (t.cause?.message ?: t.message ?: t.javaClass.simpleName), capability, t0)
        } finally {
            try { proc?.destroy() } catch (t: Throwable) { }
        }
    }

    fun sh(script: String, timeoutMs: Long = 5000L, capability: String = ""): CommandResult =
        exec(arrayOf("sh", "-c", script), timeoutMs, capability)

    /** True when the failure means "no Shizuku" rather than "the command itself failed". */
    fun unavailable(r: CommandResult): Boolean = r.exitCode == -2 || r.exitCode == -3
}
