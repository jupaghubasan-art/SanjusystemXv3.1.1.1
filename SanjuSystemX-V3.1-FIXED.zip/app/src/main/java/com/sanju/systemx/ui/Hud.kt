package com.sanju.systemx.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.sanju.systemx.core.Caps
import com.sanju.systemx.core.CapabilityEngine
import com.sanju.systemx.core.Features
import com.sanju.systemx.engine.Engine
import com.sanju.systemx.engine.WatcherService
import com.sanju.systemx.game.DnsChoice
import com.sanju.systemx.game.Effect
import com.sanju.systemx.game.GameProfile
import com.sanju.systemx.game.GameProfiles
import com.sanju.systemx.game.GpuLevel
import com.sanju.systemx.game.TouchMode
import com.sanju.systemx.gpu.GpuEngine
import com.sanju.systemx.network.NetEngine
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.thermal.ThermalState
import com.sanju.systemx.touch.TouchCtl
import java.util.Locale

/**
 * Landscape Game Space. Left rail = GAME / PERFORMANCE / DISPLAY / EFFECTS / NETWORK / TOUCH / MONITOR / SYSTEM.
 * Every control edits the selected game's profile or calls the engine; every value shown is read from the engine.
 * "--" means the metric could not be sampled right now. Nothing here is invented.
 */
class Hud(private val a: Activity, private val prefs: Prefs) {
    val view = LinearLayout(a)

    private val shizukuChip = a.tv("SHIZUKU", 11f, Pal.TEXT, true)
    private val gameChip = a.tv("GAME", 11f, Pal.TEXT, true)

    // GAME
    private val gName = Row(a, "CURRENT GAME")
    private val gStatus = Row(a, "STATUS")
    private val autoBig = a.tv("--", 26f, Pal.TEXT, true)
    private val autoSub = a.tv("", 10f, Pal.SUB)
    private val gameBtn = a.button("", false) { cycleGame() }
    private val logView = a.tv("", 10f, Pal.SUB)
    private lateinit var segAuto: Tog
    private lateinit var togGameAuto: Tog
    private lateinit var togRestore: Tog

    // PERFORMANCE
    private val perfState = StatusBlock(a, "GAME MODE + CPU")
    private val fpsTargetRow = Row(a, "AUTO FPS TARGET")
    private val gpuState = StatusBlock(a, "GPU")
    private val gpuInfoTxt = a.tv("", 10f, Pal.SUB)
    private val cpuInfoRow = Row(a, "CPU")
    private val cpuClRow = Row(a, "CLUSTER MHZ")
    private val thermalRow = Row(a, "THERMAL STATE")
    private val tCpu = Row(a, "CPU TEMP")
    private val tGpu = Row(a, "GPU TEMP")
    private val tBatt = Row(a, "BATTERY TEMP")
    private val tSvc = Row(a, "ANDROID THERMAL STATUS")
    private val bgState = StatusBlock(a, "BACKGROUND")
    private lateinit var segGpu: Seg
    private lateinit var togBg: Tog

    // DISPLAY
    private val dAct = Row(a, "ACTUAL REFRESH")
    private val dTgt = Row(a, "TARGET REFRESH")
    private val dMode = Row(a, "ACTIVE MODE")
    private val dRes = Row(a, "RESOLUTION")
    private val dState = StatusBlock(a, "REFRESH RATE")
    private val dModes = a.tv("", 10f, Pal.SUB)
    private val dFpsT = Row(a, "GAME FPS TARGET")
    private val dFpsA = Row(a, "ACTUAL FPS")

    // EFFECTS / NETWORK / TOUCH
    private val fxState = StatusBlock(a, "EFFECT")
    private lateinit var segFx: Seg
    private val dnsState = StatusBlock(a, "DNS")
    private val dnsNow = Row(a, "CURRENT DNS")
    private lateinit var segDns: Seg
    private val nPing = Row(a, "PING")
    private val nJit = Row(a, "JITTER")
    private val nLoss = Row(a, "PACKET LOSS")
    private val nDns = Row(a, "DNS LOOKUP")
    private val nQual = Row(a, "NETWORK QUALITY")
    private val nSrc = Row(a, "MEASURED BY")
    private val pingGraph = GraphView(a)
    private val touchState = StatusBlock(a, "TOUCH")
    private val touchNow = Row(a, "TOUCH-AND-HOLD DELAY")
    private val touchVendor = a.tv("", 10f, Pal.SUB)
    private lateinit var segTouch: Seg

    // MONITOR
    private val fpsBig = a.tv("--", 54f, Pal.TEXT, true)
    private val mAvg = Row(a, "AVERAGE FPS")
    private val mLow = Row(a, "1% LOW")
    private val mFt = Row(a, "FRAME TIME")
    private val mJank = Row(a, "JANK")
    private val mSrc = Row(a, "FPS SOURCE")
    private val mHz = Row(a, "REFRESH")
    private val mCpu = Row(a, "CPU")
    private val mGpu = Row(a, "GPU")
    private val mCpuF = Row(a, "CPU FREQ")
    private val mGpuF = Row(a, "GPU FREQ")
    private val mCpuT = Row(a, "CPU TEMP")
    private val mGpuT = Row(a, "GPU TEMP")
    private val mBatT = Row(a, "BATTERY TEMP")
    private val mPing = Row(a, "PING")
    private val mJit = Row(a, "JITTER")
    private val mLoss = Row(a, "PACKET LOSS")
    private val fpsNote = a.tv("", 10f, Pal.SUB)
    private val fpsGraph = GraphView(a)

    // SYSTEM
    private val capsTxt = a.tv("", 10f, Pal.SUB)
    private val sysShz = Row(a, "SHIZUKU")
    private val sysJournal = Row(a, "RESTORE JOURNAL")
    private val sysSoc = Row(a, "DEVICE")

    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()
    private var shownFps = 0f
    private var lastSeq = -1
    private var lastNetSeq = -1
    private var lastCaps: Any? = null
    private var lastPkg = ""
    private var slowAt = 0L
    private var dnsDesc = "--"
    private var touchVal = "--"
    private val need = "SHIZUKU REQUIRED"

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setBackgroundColor(Pal.BG)
        view.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))

        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = a.tv("SANJUSYSTEMX", 20f, Pal.RED, true)
        title.letterSpacing = 0.12f
        top.addView(title)
        top.addView(a.tv("  V3  GAME SPACE", 12f, Pal.TEXT, true))
        top.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
        shizukuChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        gameChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        top.addView(shizukuChip)
        top.addView(gameChip, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = a.dp(8) })
        view.addView(top)

        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        view.add(body, 8, 1f)
        body.addView(buildNav(listOf("GAME", "PERFORMANCE", "DISPLAY", "EFFECTS", "NETWORK", "TOUCH", "MONITOR", "SYSTEM")),
            LinearLayout.LayoutParams(a.dp(112), LinearLayout.LayoutParams.MATCH_PARENT))
        val content = FrameLayout(a)
        body.addView(content, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).also { it.leftMargin = a.dp(10) })

        pages.add(gamePage()); pages.add(performancePage()); pages.add(displayPage()); pages.add(effectsPage())
        pages.add(networkPage()); pages.add(touchPage()); pages.add(monitorPage()); pages.add(systemPage())
        for (p in pages) content.addView(p, FrameLayout.LayoutParams(-1, -1))
        select(0, false)

        shizukuChip.setOnClickListener { onShizukuTap() }
        syncControls()
        update()
    }

    // ---------------------------------------------------------------- profile plumbing

    private fun pkg(): String =
        if (Engine.gameFg) (Engine.profile?.packageName ?: GameProfiles.selected(prefs)) else GameProfiles.selected(prefs)

    private fun cur(): GameProfile = GameProfiles.load(prefs, pkg())

    private fun edit(what: String, f: (GameProfile) -> GameProfile) {
        GameProfiles.save(prefs, f(cur()))
        Engine.profileChanged(what)
    }

    /** Pushes the selected game's saved profile into every selector so the screen always matches what will be applied. */
    private fun syncControls() {
        val p = cur()
        lastPkg = p.packageName
        segGpu.select(GpuLevel.values().indexOf(p.preferredPerformanceMode))
        segFx.select(Effect.values().indexOf(p.preferredEffects))
        segDns.select(DnsChoice.values().indexOf(p.networkProfile))
        segTouch.select(TouchMode.values().indexOf(p.touchMode))
        gameBtn.text = "GAME: " + p.gameName + "  (TAP TO CHANGE)"
        togGameAuto.set(p.autoOptimize); togRestore.set(p.restoreOnExit); togBg.set(p.backgroundOptimization)
    }

    private fun cycleGame() {
        if (Engine.gameFg) { Toast.makeText(a, "Game is running: profile is locked to it", Toast.LENGTH_SHORT).show(); return }
        val l = GameProfiles.list(prefs)
        val i = l.indexOfFirst { it.first == GameProfiles.selected(prefs) }
        prefs.setS("selected_game", l[(i + 1) % l.size].first)
        syncControls()
        update()
    }

    // ---------------------------------------------------------------- navigation

    private fun buildNav(names: List<String>): View {
        val rail = LinearLayout(a)
        rail.orientation = LinearLayout.VERTICAL
        rail.background = a.bg(Pal.PANEL, 14, Pal.RED_DIM, 1)
        rail.setPadding(a.dp(6), a.dp(6), a.dp(6), a.dp(6))
        for ((i, n) in names.withIndex()) {
            val t = a.tv(n, 11f, Pal.SUB, true)
            t.gravity = Gravity.CENTER
            t.letterSpacing = 0.08f
            t.minHeight = a.dp(46)
            t.setOnClickListener { select(i, true) }
            navItems.add(t)
            rail.add(t, if (i == 0) 0 else 4)
        }
        val sc = ScrollView(a)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(rail)
        return sc
    }

    private fun select(i: Int, sound: Boolean) {
        if (sound) SfxHub.play(Sfx.PANEL)
        for ((k, p) in pages.withIndex()) p.visibility = if (k == i) View.VISIBLE else View.GONE
        for ((k, t) in navItems.withIndex()) {
            val on = k == i
            t.background = a.bg(if (on) Pal.RED else Color.TRANSPARENT, 10)
            t.setTextColor(if (on) Pal.TEXT else Pal.SUB)
        }
    }

    private fun twoCol(left: List<View>, right: List<View>): ScrollView {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        for ((ci, list) in listOf(left, right).withIndex()) {
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            for ((i, v) in list.withIndex()) col.add(v, if (i == 0) 0 else 10)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (ci == 1) lp.leftMargin = a.dp(10)
            row.addView(col, lp)
        }
        val sc = ScrollView(a)
        sc.isVerticalScrollBarEnabled = false
        sc.addView(row, android.view.ViewGroup.LayoutParams(-1, -2))
        return sc
    }

    // ---------------------------------------------------------------- pages

    private fun gamePage(): View {
        val game = a.panel("GAME")
        game.add(gName.view, 6)
        game.add(gStatus.view, 4)
        game.add(gameBtn, 10)
        game.add(a.button("LAUNCH GAME", true) { launchGame() }, 8)

        val auto = a.panel("SANJU AUTO GAME MODE")
        autoBig.gravity = Gravity.CENTER
        auto.add(autoBig, 6)
        autoSub.gravity = Gravity.CENTER
        auto.add(autoSub, 2)
        segAuto = Tog(a, "Auto mode (detect, optimize, restore)", prefs.getB("auto_mode", true)) { prefs.setB("auto_mode", it); Engine.kick() }
        auto.add(segAuto.view, 10)
        togGameAuto = Tog(a, "Optimize this game automatically", cur().autoOptimize) { v -> edit("none") { it.copy(autoOptimize = v) } }
        auto.add(togGameAuto.view, 8)
        togRestore = Tog(a, "Restore settings when the game exits", cur().restoreOnExit) { v -> edit("none") { it.copy(restoreOnExit = v) } }
        auto.add(togRestore.view, 8)

        val act = a.panel("ACTIONS")
        act.add(a.button("APPLY NOW", true) { Engine.applyNow() }, 6)
        act.add(a.button("RESTORE", false) { Engine.restoreNow() }, 8)
        act.add(a.button("ADD CURRENT APP AS GAME", false) { Toast.makeText(a, Engine.addCurrentAsGame(), Toast.LENGTH_SHORT).show(); update() }, 8)

        val log = a.panel("ACTIVITY")
        log.add(logView, 6)
        return twoCol(listOf(game, auto), listOf(act, log))
    }

    private fun performancePage(): View {
        val perf = a.panel("AUTO PERFORMANCE")
        perf.add(fpsTargetRow.view, 6)
        perf.add(perfState.view, 8)
        perf.add(a.tv("Game FPS target follows the panel: 60 Hz -> about 30, 90 Hz -> about 60, 120 Hz -> about 90. It is a target, never reported as the result.", 10f, Pal.SUB), 6)

        val gpu = a.panel("GPU PERFORMANCE")
        segGpu = Seg(a, GpuLevel.values().map { if (it == GpuLevel.MAXIMUM) "MAX" else it.label }, 0) { i ->
            SfxHub.play(Sfx.TOGGLE_ON); edit("gpu") { it.copy(preferredPerformanceMode = GpuLevel.values()[i]) }
        }
        gpu.add(segGpu.view, 6)
        gpu.add(gpuState.view, 8)
        gpu.add(gpuInfoTxt, 4)

        val bg = a.panel("GAME MODE BACKGROUND OPTIMIZATION")
        togBg = Tog(a, "Release unprotected background apps", cur().backgroundOptimization) { v -> edit("bg") { it.copy(backgroundOptimization = v) } }
        bg.add(togBg.view, 6)
        bg.add(bgState.view, 6)
        bg.add(a.tv("Only user-installed apps, only through Android's safe background kill. System apps, launcher, keyboard, accessibility, Shizuku and voice/messaging apps are protected.", 10f, Pal.SUB), 4)

        val cpu = a.panel("CPU")
        cpu.add(cpuInfoRow.view, 6); cpu.add(cpuClRow.view, 4)

        val th = a.panel("THERMAL")
        th.add(thermalRow.view, 6); th.add(tCpu.view, 4); th.add(tGpu.view, 4); th.add(tBatt.view, 4); th.add(tSvc.view, 4)
        return twoCol(listOf(perf, gpu, bg), listOf(cpu, th))
    }

    private fun displayPage(): View {
        val hz = a.panel("DISPLAY")
        hz.add(dAct.view, 6); hz.add(dTgt.view, 4); hz.add(dMode.view, 4); hz.add(dRes.view, 4); hz.add(dModes, 6)
        val st = a.panel("REFRESH RATE")
        st.add(dState.view, 6)
        st.add(a.button("RE-VERIFY AGAINST PANEL", false) { Engine.reverifyDisplay() }, 10)
        val fp = a.panel("GAME FPS")
        fp.add(dFpsT.view, 6); fp.add(dFpsA.view, 4)
        fp.add(a.tv("The panel can show 120 Hz while a game renders 60 FPS. These are different numbers and both are shown as measured.", 10f, Pal.SUB), 6)
        val about = a.panel("HOW TO READ THIS")
        about.add(a.tv("REQUESTED = asked. APPLIED = accepted, no read-back. VERIFIED = confirmed by reading the real panel/system. FAILED = refused or ignored. UNSUPPORTED = this hardware/Android cannot do it.", 10f, Pal.SUB), 6)
        return twoCol(listOf(hz, fp), listOf(st, about))
    }

    private fun effectsPage(): View {
        val p = a.panel("GAME EFFECTS")
        segFx = Seg(a, Effect.values().map { it.label }, 0) { i ->
            SfxHub.play(Sfx.TOGGLE_ON); edit("fx") { it.copy(preferredEffects = Effect.values()[i]) }
        }
        p.add(segFx.view, 6)
        p.add(fxState.view, 10)
        val n = a.panel("WHAT THIS DOES")
        n.add(a.tv("COOL / VIVID / CINEMATIC change the colour transform of the whole display through SurfaceFlinger. PERFORMANCE shortens system animations. DEFAULT restores everything. The game's own graphics engine is never modified. Night Light shares the same transform and can override it.", 10f, Pal.SUB), 6)
        return twoCol(listOf(p), listOf(n))
    }

    private fun networkPage(): View {
        val dns = a.panel("DNS PROFILE")
        segDns = Seg(a, DnsChoice.values().map { it.label }, 0) { i ->
            SfxHub.play(Sfx.TOGGLE_ON); edit("dns") { it.copy(networkProfile = DnsChoice.values()[i]) }
        }
        dns.add(segDns.view, 6)
        dns.add(dnsState.view, 8)
        dns.add(dnsNow.view, 6)
        dns.add(a.tv("DNS only changes name lookup. It does not lower in-match ping; ping is measured separately and honestly below.", 10f, Pal.SUB), 6)

        val net = a.panel("GAME NETWORK")
        net.add(nPing.view, 6); net.add(nJit.view, 4); net.add(nLoss.view, 4); net.add(nDns.view, 4); net.add(nQual.view, 4); net.add(nSrc.view, 4)
        net.add(pingGraph, 8, h = a.dp(70))
        net.add(a.button("TEST NOW", false) { Engine.measureNetNow() }, 8)
        return twoCol(listOf(dns), listOf(net))
    }

    private fun touchPage(): View {
        val p = a.panel("TOUCH RESPONSE")
        segTouch = Seg(a, TouchMode.values().map { it.label }, 1) { i ->
            SfxHub.play(Sfx.TOGGLE_ON); edit("touch") { it.copy(touchMode = TouchMode.values()[i]) }
        }
        p.add(segTouch.view, 6)
        p.add(touchState.view, 8)
        p.add(touchNow.view, 6)
        val n = a.panel("WHAT THIS DOES")
        n.add(a.tv("Android exposes no setting that lowers hardware touch latency. FAST and SLOW change the system touch-and-hold delay (how quickly a press-and-hold is recognised), read back and restored when the game exits.", 10f, Pal.SUB), 6)
        n.add(touchVendor, 6)
        return twoCol(listOf(p), listOf(n))
    }

    private fun monitorPage(): View {
        val f = a.panel("FPS MONITOR")
        fpsBig.gravity = Gravity.CENTER
        f.add(a.tv("ACTUAL FPS", 10f, Pal.SUB), 2)
        f.add(fpsBig)
        f.add(mAvg.view, 4); f.add(mLow.view, 3); f.add(mFt.view, 3); f.add(mJank.view, 3); f.add(mSrc.view, 3)
        f.add(fpsGraph, 6, h = a.dp(90))
        f.add(fpsNote, 4)

        val s = a.panel("SYSTEM")
        s.add(mHz.view, 6); s.add(mCpu.view, 4); s.add(mGpu.view, 4); s.add(mCpuF.view, 4); s.add(mGpuF.view, 4)
        s.add(mCpuT.view, 4); s.add(mGpuT.view, 4); s.add(mBatT.view, 4)

        val n = a.panel("NETWORK")
        n.add(mPing.view, 6); n.add(mJit.view, 4); n.add(mLoss.view, 4)
        return twoCol(listOf(f), listOf(s, n))
    }

    private fun systemPage(): View {
        val st = a.panel("SYSTEM")
        st.add(Tog(a, "SOUND EFFECTS", prefs.getB("sfx_on", true)) { prefs.setB("sfx_on", it) }.view, 6)
        st.add(Tog(a, "Sounds while a game is running", prefs.getB("sfx_in_game", false)) { prefs.setB("sfx_in_game", it) }.view, 8)
        st.add(Tog(a, "Haptic feedback", prefs.getB("haptic", true)) { prefs.setB("haptic", it); Pal.haptic = it }.view, 8)
        st.add(Tog(a, "Background watcher (notification)", prefs.getB("watcher", true)) {
            prefs.setB("watcher", it)
            if (it) startWatcher() else a.stopService(Intent(a, WatcherService::class.java))
        }.view, 8)

        val vol = a.panel("SOUND VOLUME")
        val v0 = prefs.getF("sfx_vol", 0.7f)
        val sel = if (v0 < 0.5f) 0 else if (v0 < 0.85f) 1 else 2
        val levels = floatArrayOf(0.35f, 0.7f, 1.0f)
        vol.add(Seg(a, listOf("LOW", "MEDIUM", "HIGH"), sel) { prefs.setF("sfx_vol", levels[it]); SfxHub.play(Sfx.SUCCESS) }.view, 6)

        val dev = a.panel("DEVICE")
        dev.add(sysShz.view, 6); dev.add(sysSoc.view, 4); dev.add(sysJournal.view, 4)
        dev.add(a.button("RE-DETECT CAPABILITIES", false) { Engine.redetect() }, 8)

        val caps = a.panel("CAPABILITIES")
        caps.add(capsTxt, 6)
        return twoCol(listOf(st, vol, dev), listOf(caps))
    }

    fun startWatcher() {
        try { a.startForegroundService(Intent(a, WatcherService::class.java)) } catch (t: Throwable) { Engine.log("Could not start watcher: " + (t.message ?: "")) }
    }

    private fun launchGame() {
        val p = pkg()
        val i = a.packageManager.getLaunchIntentForPackage(p)
        if (i == null) {
            SfxHub.play(Sfx.WARNING)
            Toast.makeText(a, cur().gameName + " is not installed", Toast.LENGTH_SHORT).show()
        } else {
            SfxHub.play(Sfx.GAME_LAUNCH)
            a.startActivity(i)
        }
    }

    private fun onShizukuTap() {
        when (Engine.shizuku) {
            ShizukuState.PERMISSION_REQUIRED -> ShizukuBridge.requestPermission()
            ShizukuState.DISCONNECTED -> {
                val i = a.packageManager.getLaunchIntentForPackage(ShizukuBridge.PKG)
                if (i != null) a.startActivity(i)
                else { SfxHub.play(Sfx.WARNING); Toast.makeText(a, "Install and start Shizuku first", Toast.LENGTH_LONG).show() }
            }
            else -> Engine.kick()
        }
    }

    private fun chip(t: TextView, text: String, color: Int) {
        t.text = text
        t.background = a.bg(Color.argb(60, Color.red(color), Color.green(color), Color.blue(color)), 8, color, 1)
        t.setTextColor(color)
    }

    // ---------------------------------------------------------------- formatting helpers

    private fun n0(v: Float, unit: String): String = if (v >= 0f) Math.round(v).toString() + unit else "--"
    private fun n1(v: Float, unit: String): String = if (v >= 0f) String.format(Locale.US, "%.1f", v) + unit else "--"
    private fun deg(v: Float): String = n1(v, " C")

    // ---------------------------------------------------------------- refresh (4x per second while visible)

    fun update() {
        val s = Engine.shizuku
        val ok = s == ShizukuState.CONNECTED
        if (pkg() != lastPkg) syncControls()
        val prof = cur()

        when (s) {
            ShizukuState.CONNECTED -> chip(shizukuChip, "SHIZUKU  CONNECTED", Pal.GREEN)
            ShizukuState.PERMISSION_REQUIRED -> chip(shizukuChip, "SHIZUKU  PERMISSION REQUIRED (TAP)", Pal.AMBER)
            ShizukuState.UNSUPPORTED -> chip(shizukuChip, "SHIZUKU  UNSUPPORTED", Pal.RED)
            ShizukuState.DISCONNECTED -> chip(shizukuChip, "SHIZUKU  DISCONNECTED (TAP)", Pal.RED)
        }
        if (!ok) chip(gameChip, "GAME  $need", Pal.AMBER)
        else if (!Engine.fgKnown) chip(gameChip, "GAME  DETECTION UNAVAILABLE", Pal.AMBER)
        else if (Engine.gameFg) chip(gameChip, "GAME  " + prof.gameName.uppercase(Locale.US) + " DETECTED", Pal.GREEN)
        else chip(gameChip, "GAME  IDLE", Pal.SUB)

        // GAME
        gName.set(prof.gameName)
        gStatus.set(if (!ok) need else if (Engine.gameFg) "RUNNING" else "NOT RUNNING", if (Engine.gameFg) Pal.GREEN else Pal.SUB)
        val autoOn = prefs.getB("auto_mode", true)
        val (autoTxt, autoCol) = when {
            !ok -> need to Pal.AMBER
            !autoOn -> "OFF" to Pal.SUB
            Engine.busy -> "OPTIMIZING" to Pal.AMBER
            Engine.applied && Engine.thermal == ThermalState.PROTECTION -> "THERMAL PROTECTION" to Pal.AMBER
            Engine.applied -> "ACTIVE" to Pal.GREEN
            else -> "STANDBY" to Pal.SUB
        }
        autoBig.text = autoTxt; autoBig.setTextColor(autoCol)
        autoSub.text = if (Engine.applied) Engine.lastSummary else "Waiting for a configured game"
        logView.text = Engine.logTail(7).joinToString("\n")

        // PERFORMANCE
        val tf = Engine.targetFps
        fpsTargetRow.set(if (tf > 0) "about $tf FPS  (" + Engine.hzMax + " Hz panel)" else "--")
        perfState.set(Features.get(Features.PERF))
        gpuState.set(Features.get(Features.GPU))
        val g = CapabilityEngine.gpu
        gpuInfoTxt.text = if (g == null) (if (CapabilityEngine.detected) "No readable GPU interface" else "") else
            g.vendor + (if (g.renderer.isNotEmpty()) "  |  " + g.renderer.take(48) else "") +
                (if (g.usable.size >= 2) "\nSteps: " + g.usable.joinToString(" / ") { GpuEngine.toMhz(it).toString() } + " MHz" else "") +
                (if (!g.writableMin && g.dir.isNotEmpty()) "\nFrequency node is read-only for this app (monitoring only)" else "")
        bgState.set(Features.get(Features.BG))
        cpuInfoRow.set(com.sanju.systemx.cpu.CpuEngine.describe(CapabilityEngine.cpu))
        cpuClRow.set(if (Engine.cpuClusters.isEmpty()) "--" else Engine.cpuClusters)
        val th = Engine.thermal
        thermalRow.set(th.label, when (th) { ThermalState.NORMAL -> Pal.SUB; ThermalState.PERFORMANCE -> Pal.GREEN; else -> Pal.AMBER })
        tCpu.set(deg(Engine.cpuTemp)); tGpu.set(deg(Engine.gpuTemp)); tBatt.set(deg(Engine.battTemp))
        tSvc.set(if (Engine.thermalStatus >= 0) Engine.thermalStatus.toString() + " (0 = none)" else "--")

        // DISPLAY
        val hzNow = if (Engine.hzActual > 0f) Engine.hzActual else DisplayCtl.current(a)
        dAct.set(if (hzNow > 0f) Math.round(hzNow).toString() + " Hz" else "--")
        dTgt.set(if (Engine.hzTarget > 0) Engine.hzTarget.toString() + " Hz" else if (Engine.hzMax > 0) Engine.hzMax.toString() + " Hz (when a game starts)" else "--")
        dMode.set(DisplayCtl.describeActive(a)); dRes.set(DisplayCtl.resolution(a))
        val rates = DisplayCtl.rates(a)
        dModes.text = "SUPPORTED REFRESH RATES: " + (if (rates.isEmpty()) "UNKNOWN" else rates.joinToString(" / ") + " Hz")
        dState.set(Features.get(Features.DISPLAY))
        dFpsT.set(if (tf > 0) "about $tf FPS" else "--")
        dFpsA.set(n0(Engine.frames.fps, " FPS"))

        // EFFECTS / NETWORK / TOUCH
        fxState.set(Features.get(Features.EFFECT))
        dnsState.set(Features.get(Features.DNS))
        touchState.set(Features.get(Features.TOUCH))
        val now = System.currentTimeMillis()
        if (ok && now - slowAt > 4000L) {   // shell reads are refreshed slowly, never at 4 Hz
            slowAt = now
            Thread { try { dnsDesc = NetEngine.currentDescription(a); touchVal = TouchCtl.current() } catch (t: Throwable) { } }.start()
        }
        dnsNow.set(dnsDesc)
        touchNow.set(if (touchVal == "null") "system default" else if (touchVal == "--") "--" else "$touchVal ms")
        touchVendor.text = if (CapabilityEngine.vendorTouchKeys.isEmpty()) "No vendor touch/game keys were found on this device."
            else "Vendor keys found but NOT modified (their meaning is unknown):\n" + CapabilityEngine.vendorTouchKeys.take(5).joinToString("\n")

        nPing.set(n1(NetEngine.pingMs, " ms")); nJit.set(n1(NetEngine.jitterMs, " ms")); nLoss.set(n1(NetEngine.lossPct, " %"))
        nDns.set(n0(NetEngine.dnsLookupMs, " ms")); nQual.set(NetEngine.quality)
        nSrc.set(if (NetEngine.source.isEmpty()) "--" else NetEngine.source + " to " + NetEngine.anchor)
        mPing.set(n1(NetEngine.pingMs, " ms")); mJit.set(n1(NetEngine.jitterMs, " ms")); mLoss.set(n1(NetEngine.lossPct, " %"))
        if (NetEngine.seq != lastNetSeq) { lastNetSeq = NetEngine.seq; pingGraph.push(NetEngine.pingMs) }

        // MONITOR
        val fs = Engine.frames
        val fps = fs.fps
        if (Engine.gameFg && fps >= 0f) { shownFps += (fps - shownFps) * 0.4f; fpsBig.text = Math.round(shownFps).toString() }
        else { shownFps = 0f; fpsBig.text = "--" }
        mAvg.set(n0(fs.avg, " FPS")); mLow.set(n0(fs.low1, " FPS")); mFt.set(n1(fs.frameMs, " ms"))
        mJank.set(n1(fs.jankPct, " % of frames")); mSrc.set(if (Engine.fpsSource.isEmpty() || !Engine.gameFg) "--" else Engine.fpsSource)
        fpsNote.text = if (!ok) need else if (!Engine.gameFg) "Start a configured game to measure FPS" else Engine.fpsNote
        if (Engine.sampleSeq != lastSeq) { lastSeq = Engine.sampleSeq; fpsGraph.push(if (Engine.gameFg) fs.fps else -1f) }
        mHz.set(n0(hzNow, " Hz"))
        mCpu.set(if (!ok) need else n0(Engine.cpuPct, " %"))
        mGpu.set(if (!ok) need else n0(Engine.gpuPct, " %"))
        mCpuF.set(if (Engine.cpuMhz > 0) Engine.cpuMhz.toString() + " MHz (peak core)" else "--")
        mGpuF.set(if (Engine.gpuMhz > 0) Engine.gpuMhz.toString() + " MHz" else "--")
        mCpuT.set(deg(Engine.cpuTemp)); mGpuT.set(deg(Engine.gpuTemp)); mBatT.set(deg(Engine.battTemp))

        // SYSTEM
        sysShz.set(if (ok) "CONNECTED (" + ShizukuBridge.privilegeLabel() + ")" else s.name, if (ok) Pal.GREEN else Pal.AMBER)
        sysSoc.set(if (CapabilityEngine.socLabel.isEmpty()) "--" else CapabilityEngine.socLabel)
        sysJournal.set(Journal.size(prefs).toString() + " entries")
        val cl = Caps.list
        if (cl !== lastCaps) {
            lastCaps = cl
            capsTxt.text = if (cl.isEmpty()) "Waiting for Shizuku to detect capabilities..." else cl.joinToString("\n\n") { c ->
                val tag = if (!c.supported) "NOT SUPPORTED" else if (c.controllable) "CONTROLLABLE" else "READ-ONLY"
                c.name + "  [" + tag + (if (c.verified) ", VERIFIED" else "") + "]\n" + c.reason + "  (" + c.backend + ")"
            }
        }
    }
}
