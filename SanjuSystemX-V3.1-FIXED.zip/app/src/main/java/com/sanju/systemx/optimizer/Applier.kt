package com.sanju.systemx.optimizer

import android.content.Context
import android.os.Build
import com.sanju.systemx.core.Cap
import com.sanju.systemx.core.CapabilityEngine
import com.sanju.systemx.core.Caps
import com.sanju.systemx.core.Features
import com.sanju.systemx.core.St
import com.sanju.systemx.cpu.CpuEngine
import com.sanju.systemx.effects.EffectsEngine
import com.sanju.systemx.game.AutoTarget
import com.sanju.systemx.game.GameProfile
import com.sanju.systemx.game.GpuLevel
import com.sanju.systemx.gpu.GpuEngine
import com.sanju.systemx.network.NetEngine
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.touch.TouchCtl

/**
 * Runs the DETECT -> APPLY -> VERIFY pipeline for one game and restores everything from the journal.
 * Each step is independent: one failing step never blocks the others, and every outcome is written to [Features].
 */
object Applier {
    class Summary(val applied: Int, val verified: Int, val failed: Int, val unsupported: Int, val targetHz: Int, val log: List<String>)

    private val BAD = listOf("error", "usage:", "unknown command", "exception", "invalid", "not found", "denied", "unsupported")

    private fun bad(s: String): Boolean = BAD.any { s.contains(it, true) }

    // ---------------------------------------------------------------- game mode + game FPS intervention

    private fun gameModeReads(pkg: String): String =
        ShizukuBridge.sh("cmd game mode $pkg 2>&1", 4000L, "GAME_MODE").out

    private fun setGameMode(prefs: Prefs, pkg: String, fps: Int): Pair<St, String> {
        if (Build.VERSION.SDK_INT < 31 || !Caps.controllable(Cap.GAME_MODE)) return St.UNSUPPORTED to "Game Mode needs Android 12+"
        if (!pkg.matches(Regex("[A-Za-z0-9_.]+"))) return St.FAILED to "Bad package name"
        Journal.saveOnce(prefs, "game.$pkg", "1")
        val tries = ArrayList<String>()
        if (fps > 0 && Build.VERSION.SDK_INT >= 33) tries.add("cmd game set --mode performance --fps $fps $pkg 2>&1")
        tries.add("cmd game set --mode performance $pkg 2>&1")
        tries.add("cmd game mode performance $pkg 2>&1")
        var fpsFlagUsed = false
        var accepted = false
        for ((i, c) in tries.withIndex()) {
            val r = ShizukuBridge.sh(c, 5000L, "GAME_MODE")
            if (r.success && !bad(r.out)) { accepted = true; fpsFlagUsed = (i == 0 && fps > 0 && Build.VERSION.SDK_INT >= 33); break }
        }
        if (!accepted) return St.FAILED to "GameManager rejected the performance mode"
        val back = gameModeReads(pkg).lowercase()
        Features.set(Features.FPSCAP, if (fpsFlagUsed) St.APPLIED else St.UNSUPPORTED,
            if (fpsFlagUsed) "Game Mode FPS intervention $fps requested (a hint/cap; the game's own limit still applies)" else "FPS intervention not available here")
        return if (back.contains("performance") || Regex("""\b(mode|game mode)\W+2\b""").containsMatchIn(back))
            St.VERIFIED to "Game Mode = PERFORMANCE (read back)"
        else St.APPLIED to "Game Mode accepted (no read-back on this build)"
    }

    // ---------------------------------------------------------------- the pipeline

    fun apply(ctx: Context, prefs: Prefs, p: GameProfile, onStep: (String) -> Unit): Summary {
        val log = ArrayList<String>()
        fun say(s: String) { log.add(s); onStep(s) }
        Features.clear()
        val maxHz = DisplayCtl.maxRate(ctx)
        val fpsTarget = AutoTarget.gameFps(maxHz)

        // 1) PERFORMANCE: game mode (+FPS intervention) and CPU hint
        try {
            val gm = setGameMode(prefs, p.packageName, fpsTarget)
            val cpuR = CpuEngine.applyPerformanceHint(prefs, CapabilityEngine.cpu)
            val st = best(gm.first, cpuR.st)
            Features.set(Features.PERF, st, "GAME MODE: " + gm.second + "  |  CPU: " + cpuR.detail)
            say("PERFORMANCE: " + gm.second)
        } catch (t: Throwable) { Features.set(Features.PERF, St.FAILED, t.message ?: "error") }

        // 2) DISPLAY
        var hzTarget = 0
        try {
            val r = DisplayCtl.request(ctx, prefs)
            hzTarget = r.targetHz
            Features.set(Features.DISPLAY, r.state, r.detail)
            say("DISPLAY: " + r.detail)
        } catch (t: Throwable) { Features.set(Features.DISPLAY, St.FAILED, t.message ?: "error") }

        // 3) GPU
        try { applyGpu(prefs, p.preferredPerformanceMode, ::say) } catch (t: Throwable) { Features.set(Features.GPU, St.FAILED, t.message ?: "error") }

        // 4) EFFECTS
        try {
            val r = EffectsEngine.apply(prefs, p.preferredEffects)
            Features.set(Features.EFFECT, r.st, p.preferredEffects.label + ": " + r.detail)
            say("EFFECT " + p.preferredEffects.label + ": " + r.detail)
        } catch (t: Throwable) { Features.set(Features.EFFECT, St.FAILED, t.message ?: "error") }

        // 5) NETWORK / DNS
        try {
            val r = NetEngine.apply(ctx, prefs, p.networkProfile)
            Features.set(Features.DNS, if (r.st == St.VERIFIED && p.networkProfile.host.isEmpty()) St.IDLE else r.st, r.detail)
            say("DNS: " + r.detail)
        } catch (t: Throwable) { Features.set(Features.DNS, St.FAILED, t.message ?: "error") }

        // 6) TOUCH
        try {
            val r = TouchCtl.apply(prefs, p.touchMode)
            Features.set(Features.TOUCH, if (p.touchMode.name == "DEFAULT") St.IDLE else r.st, r.detail)
            say("TOUCH: " + r.detail)
        } catch (t: Throwable) { Features.set(Features.TOUCH, St.FAILED, t.message ?: "error") }

        // 7) BACKGROUND
        try {
            if (p.backgroundOptimization) {
                val r = BgOptimizer.run(ctx, prefs, p.packageName)
                Features.set(Features.BG, r.st, r.detail)
                say("BACKGROUND: " + r.detail)
            } else Features.set(Features.BG, St.IDLE, "Off for this game")
        } catch (t: Throwable) { Features.set(Features.BG, St.FAILED, t.message ?: "error") }

        // 8) VERIFY the display against the real panel
        if (hzTarget > 0 && Features.get(Features.DISPLAY).st == St.REQUESTED) {
            val v = DisplayCtl.verify(ctx, hzTarget)
            Features.set(Features.DISPLAY, v.first, v.second)
            say("DISPLAY: " + v.second)
        }
        return summarize(hzTarget, log)
    }

    private fun best(a: St, b: St): St {
        val order = listOf(St.VERIFIED, St.APPLIED, St.REQUESTED, St.FAILED, St.UNSUPPORTED, St.IDLE)
        return if (order.indexOf(a) <= order.indexOf(b)) a else b
    }

    private fun summarize(hz: Int, log: List<String>): Summary {
        var ap = 0; var ve = 0; var fa = 0; var un = 0
        for (n in listOf(Features.PERF, Features.DISPLAY, Features.GPU, Features.EFFECT, Features.DNS, Features.TOUCH, Features.BG)) {
            when (Features.get(n).st) { St.APPLIED -> ap++; St.VERIFIED -> ve++; St.FAILED -> fa++; St.UNSUPPORTED -> un++; else -> {} }
        }
        return Summary(ap, ve, fa, un, hz, log)
    }

    /** GPU step, also used by the thermal governor to step performance back up or down. */
    fun applyGpu(prefs: Prefs, level: GpuLevel, say: (String) -> Unit = {}) {
        val info = CapabilityEngine.gpu
        if (info == null) { Features.set(Features.GPU, St.UNSUPPORTED, "No GPU interface on this device"); return }
        val r = GpuEngine.apply(prefs, info, level)
        Features.set(Features.GPU, r.st, level.label + ": " + r.detail)
        say("GPU: " + r.detail)
    }

    // ---------------------------------------------------------------- restore

    fun hasJournal(prefs: Prefs): Boolean = Journal.hasEntries(prefs)

    /** Restores everything recorded in the journal. Entries that fail stay in the journal and are retried later. */
    fun restore(prefs: Prefs): List<String> {
        val j = Journal.load(prefs)
        if (j.isEmpty()) return listOf("NOTHING TO RESTORE")
        val lines = ArrayList<String>()
        val remaining = LinkedHashMap<String, String>()
        if (j.containsKey("fx.color")) {
            if (com.sanju.systemx.effects.SfColorBackend.restore()) lines.add("RESTORED display colours") else { remaining["fx.color"] = "1"; lines.add("RESTORE FAILED display colours (will retry)") }
        }
        for ((k, v) in j) {
            if (k == "fx.color") continue
            val ok: Boolean = try {
                when {
                    k.startsWith("set.") -> {
                        val parts = k.split('.', limit = 3)
                        parts.size == 3 && Sett.restore(parts[1], parts[2], v)
                    }
                    k == "sys.min_refresh_rate" -> Sett.restore("system", "min_refresh_rate", v)       // legacy V3 keys
                    k == "sys.peak_refresh_rate" -> Sett.restore("system", "peak_refresh_rate", v)
                    k.startsWith("game.") && k != "game.mode" -> {
                        val pkg = k.removePrefix("game.")
                        pkg.matches(Regex("[A-Za-z0-9_.]+")) && resetGame(pkg)
                    }
                    k == "game.mode" -> resetGame(com.sanju.systemx.game.GameProfiles.MLBB)
                    k == "gpu.min" -> GpuEngine.release(prefs)
                    k == "power.fixed" -> CpuEngine.releasePerformanceHint()
                    else -> true
                }
            } catch (t: Throwable) { false }
            if (ok) lines.add("RESTORED $k") else { remaining[k] = v; lines.add("RESTORE FAILED $k (will retry)") }
        }
        Journal.save(prefs, remaining)
        return lines
    }

    /** Restores only the named settings keys (used when one feature is changed while a game is running). */
    fun restoreKeys(prefs: Prefs, keys: List<String>) {
        val j = Journal.load(prefs)
        var changed = false
        for (k in keys) {
            val v = j[k] ?: continue
            val parts = k.split('.', limit = 3)
            if (parts.size == 3 && Sett.restore(parts[1], parts[2], v)) { j.remove(k); changed = true }
        }
        if (changed) Journal.save(prefs, j)
    }

    private fun resetGame(pkg: String): Boolean {
        val r = ShizukuBridge.sh("cmd game reset $pkg 2>&1", 4000L, "GAME_MODE")
        if (r.success && !bad(r.out)) return true
        val s = ShizukuBridge.sh("cmd game set --mode standard $pkg 2>&1", 4000L, "GAME_MODE")
        if (s.success && !bad(s.out)) return true
        val m = ShizukuBridge.sh("cmd game mode standard $pkg 2>&1", 4000L, "GAME_MODE")
        return m.success && !bad(m.out)
    }
}
