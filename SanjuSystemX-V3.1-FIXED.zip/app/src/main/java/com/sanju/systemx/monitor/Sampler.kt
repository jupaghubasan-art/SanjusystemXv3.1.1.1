package com.sanju.systemx.monitor

import com.sanju.systemx.shizuku.CommandResult
import com.sanju.systemx.shizuku.ShizukuBridge
import java.util.Locale

/** One parsed sample of what the shell could read. Missing sections stay empty = unavailable. */
class Raw(
    val stat: String?,
    val freqs: List<Long>,
    val clusters: List<Pair<Long, Long>>,   // (current kHz, max kHz) per cpufreq policy
    val types: Map<String, String>,
    val temps: Map<String, Float>,
    val gpuF: String?,
    val gpuB: List<String>,
    val fps: List<String>,
    val fg: String?,
    val complete: Boolean
)

object Sampler {
    // '§' stands for '$' so Kotlin does not treat it as a template. Args: §1=gpu dir, §2=SurfaceFlinger layer, §3=check foreground (1/0)
    private val FULL = """
G="§1"; L="§2"; FG="§3"
echo "@@STAT"; head -n 1 /proc/stat
echo "@@FREQ"; cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null
echo "@@CPUF"; for p in /sys/devices/system/cpu/cpufreq/policy*; do [ -r "§p/scaling_cur_freq" ] && echo "§(cat §p/scaling_cur_freq) §(cat §p/cpuinfo_max_freq 2>/dev/null)"; done
echo "@@TYPE"; grep -H '' /sys/class/thermal/thermal_zone*/type 2>/dev/null
echo "@@TEMP"; grep -H '' /sys/class/thermal/thermal_zone*/temp 2>/dev/null
echo "@@GPUF"; if [ -n "§G" ]; then cat "§G/cur_freq" 2>/dev/null; fi
echo "@@GPUB"; cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null; cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; cat /sys/kernel/gpu/gpu_busy 2>/dev/null; if [ -n "§G" ]; then cat "§G/load" 2>/dev/null; fi
echo "@@FPS"; if [ -n "§L" ]; then dumpsys SurfaceFlinger --latency "§L" 2>/dev/null; fi
if [ "§FG" = "1" ]; then
  echo "@@FG"
  r=§(dumpsys activity activities 2>/dev/null | grep -m2 ResumedActivity)
  if [ -z "§r" ]; then r=§(dumpsys window 2>/dev/null | grep -m2 -E 'mCurrentFocus|mFocusedApp'); fi
  echo "§r"
fi
echo "@@END"
""".replace('§', '$')

    private val FG_ONLY = """
echo "@@FG"
r=§(dumpsys activity activities 2>/dev/null | grep -m2 ResumedActivity)
if [ -z "§r" ]; then r=§(dumpsys window 2>/dev/null | grep -m2 -E 'mCurrentFocus|mFocusedApp'); fi
echo "§r"
echo "@@END"
""".replace('§', '$')

    fun sampleFull(gpuDir: String, layer: String, checkFg: Boolean): Raw? {
        val r = ShizukuBridge.exec(arrayOf("sh", "-c", FULL, "sx", gpuDir, layer, if (checkFg) "1" else "0"), 6000L, "MONITOR")
        return if (ShizukuBridge.unavailable(r)) null else parse(r.stdout)
    }

    fun sampleFg(): Raw? {
        val r = ShizukuBridge.exec(arrayOf("sh", "-c", FG_ONLY), 6000L, "FOREGROUND")
        return if (ShizukuBridge.unavailable(r)) null else parse(r.stdout)
    }

    private fun zoneId(path: String): String {
        val i = path.indexOf("thermal_zone")
        if (i < 0) return path
        val rest = path.substring(i + 12)
        val j = rest.indexOf('/')
        return if (j > 0) rest.substring(0, j) else rest
    }

    fun parse(out: String): Raw {
        var sec = ""
        var stat: String? = null
        val freqs = ArrayList<Long>()
        val clusters = ArrayList<Pair<Long, Long>>()
        val types = HashMap<String, String>()
        val temps = HashMap<String, Float>()
        var gpuF: String? = null
        val gpuB = ArrayList<String>()
        val fps = ArrayList<String>()
        val fg = StringBuilder()
        var fgSeen = false
        var end = false
        for (raw in out.lines()) {
            val line = raw.trim()
            if (line.startsWith("@@")) {
                sec = line.substring(2)
                if (sec == "FG") fgSeen = true
                if (sec == "END") end = true
                continue
            }
            if (line.isEmpty()) continue
            when (sec) {
                "STAT" -> { if (stat == null) stat = line }
                "FREQ" -> { val v = line.toLongOrNull(); if (v != null) freqs.add(v) }
                "CPUF" -> {
                    val p = line.split(' ')
                    val c = p.getOrNull(0)?.toLongOrNull()
                    if (c != null) clusters.add(c to (p.getOrNull(1)?.toLongOrNull() ?: -1L))
                }
                "TYPE" -> { val i = line.indexOf(':'); if (i > 0) types[zoneId(line.substring(0, i))] = line.substring(i + 1).trim() }
                "TEMP" -> {
                    val i = line.indexOf(':')
                    if (i > 0) {
                        val v = line.substring(i + 1).trim().toFloatOrNull()
                        if (v != null) temps[zoneId(line.substring(0, i))] = v
                    }
                }
                "GPUF" -> { if (gpuF == null) gpuF = line }
                "GPUB" -> { gpuB.add(line) }
                "FPS" -> { fps.add(line) }
                "FG" -> { if (fg.isNotEmpty()) fg.append(' '); fg.append(line) }
            }
        }
        return Raw(stat, freqs, clusters, types, temps, gpuF, gpuB, fps, if (fgSeen) fg.toString() else null, end)
    }

    /** GPU utilisation from the known formats only: "NN %", "busy total" counters, devfreq "NN@freqHz". -1 = unknown. */
    fun gpuBusy(lines: List<String>): Float {
        for (l in lines) {
            val t = l.trim()
            val at = t.indexOf('@')
            if (at > 0) { val v = t.substring(0, at).trim().toFloatOrNull(); if (v != null) return v.coerceIn(0f, 100f) }
        }
        for (l in lines) {
            val t = l.trim()
            if (t.contains("%")) {
                val v = t.replace("%", "").trim().toFloatOrNull()
                if (v != null) return v.coerceIn(0f, 100f)
            }
        }
        for (l in lines) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size == 2) {
                val a = p[0].toLongOrNull(); val b = p[1].toLongOrNull()
                if (a != null && b != null && b > 0L) return (a * 100f / b).coerceIn(0f, 100f)
            }
        }
        return -1f
    }

    // ---------------------------------------------------------------- FPS sources

    /** SurfaceFlinger --latency: line 0 = vsync period, then "desired actual ready" per frame. Returns actual-present timestamps. */
    fun sfStamps(lines: List<String>): List<Long> {
        if (lines.size < 2) return emptyList()
        val ts = ArrayList<Long>()
        for (i in 1 until lines.size) {
            val p = lines[i].trim().split(Regex("\\s+"))
            if (p.size >= 3) {
                val v = p[1].toLongOrNull() ?: continue
                if (v > 0L && v < Long.MAX_VALUE / 2) ts.add(v)
            }
        }
        return ts
    }

    /** Fallback source: gfxinfo framestats (HWUI-rendered apps only). Returns FRAME_COMPLETED timestamps. */
    fun fetchGfxStamps(pkg: String): List<Long> {
        if (!pkg.matches(Regex("[A-Za-z0-9_.]+"))) return emptyList()
        val r: CommandResult = ShizukuBridge.sh("dumpsys gfxinfo $pkg framestats 2>/dev/null", 6000L, "FPS_MONITOR")
        val out = ArrayList<Long>()
        var inBlock = false
        var idxDone = -1
        var idxFlags = 0
        var header = false
        for (raw in r.stdout.lines()) {
            val l = raw.trim()
            if (l == "---PROFILEDATA---") { inBlock = !inBlock; header = inBlock; continue }
            if (!inBlock || l.isEmpty()) continue
            val c = l.split(',')
            if (header) { idxFlags = c.indexOf("Flags").coerceAtLeast(0); idxDone = c.indexOf("FrameCompleted"); header = false; continue }
            if (idxDone < 0 || c.size <= idxDone) continue
            if ((c.getOrNull(idxFlags)?.toLongOrNull() ?: 0L) != 0L) continue
            val v = c[idxDone].toLongOrNull() ?: continue
            if (v > 0L && v < Long.MAX_VALUE / 2) out.add(v)
        }
        return out
    }

    fun discoverLayers(pkg: String): List<String> {
        if (!pkg.matches(Regex("[A-Za-z0-9_.]+"))) return emptyList()
        val r = ShizukuBridge.sh("dumpsys SurfaceFlinger --list 2>/dev/null | grep '$pkg'", 6000L, "FPS_MONITOR")
        val all = r.stdout.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("Background for") && !it.contains("Bounds for") }
        val sv = all.filter { it.startsWith("SurfaceView[") }
        return if (sv.isNotEmpty()) sv + all.filter { !it.startsWith("SurfaceView[") } else all
    }

    fun normTemp(v: Float): Float = if (v >= 1000f) v / 1000f else v

    fun isCpuZone(t: String): Boolean {
        val s = t.lowercase(Locale.US)
        return s.contains("cpu") || s.contains("cluster") || s == "big" || s == "mid" || s == "little"
    }

    fun isGpuZone(t: String): Boolean {
        val s = t.lowercase(Locale.US)
        return s.contains("gpu") || s.contains("kgsl") || s.contains("mali") || s == "g3d"
    }
}

/** CPU usage from /proc/stat deltas. */
class Calc {
    private var pTotal = 0L
    private var pIdle = 0L
    private var havePrev = false

    fun cpu(stat: String?): Float {
        if (stat == null) return -1f
        val p = stat.trim().split(Regex("\\s+"))
        if (p.size < 5) return -1f
        var total = 0L
        for (i in 1 until minOf(p.size, 9)) total += p[i].toLongOrNull() ?: 0L
        val idle = (p[4].toLongOrNull() ?: 0L) + (if (p.size > 5) (p[5].toLongOrNull() ?: 0L) else 0L)
        val r: Float
        if (!havePrev) {
            r = -1f
        } else {
            val dT = total - pTotal
            val dI = idle - pIdle
            r = if (dT <= 0L) -1f else ((dT - dI).toFloat() * 100f / dT.toFloat()).coerceIn(0f, 100f)
        }
        pTotal = total
        pIdle = idle
        havePrev = true
        return r
    }

    fun resetCpu() { havePrev = false }
}
