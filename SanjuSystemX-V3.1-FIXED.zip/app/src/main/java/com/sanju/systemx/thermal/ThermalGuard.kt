package com.sanju.systemx.thermal

enum class ThermalState(val label: String) {
    NORMAL("NORMAL"), PERFORMANCE("PERFORMANCE"), WARNING("THERMAL WARNING"), PROTECTION("THERMAL PROTECTION")
}

/**
 * Pure decision logic with hysteresis. Inputs are real readings (-1 = unknown, ignored).
 * Thresholds are conservative on purpose: the app must never push a device into damage for FPS.
 *  - Android thermal status (0 none ... 6 shutdown) from thermalservice when readable.
 */
object ThermalGuard {
    private const val HOT_WARN = 75f
    private const val HOT_PROT = 85f
    private const val BATT_WARN = 41f
    private const val BATT_PROT = 44f
    private const val MARGIN = 4f

    fun level(cpu: Float, gpu: Float, batt: Float, status: Int, prev: ThermalState): Int {
        val hot = maxOf(cpu, gpu)
        val sticky = if (prev == ThermalState.WARNING || prev == ThermalState.PROTECTION) MARGIN else 0f
        val protNow = status >= 3 || hot >= HOT_PROT - (if (prev == ThermalState.PROTECTION) MARGIN else 0f) ||
            batt >= BATT_PROT - (if (prev == ThermalState.PROTECTION) 2f else 0f)
        if (protNow && (hot >= 0f || batt >= 0f || status >= 3)) return 2
        val warnNow = status >= 2 || hot >= HOT_WARN - sticky || batt >= BATT_WARN - (if (sticky > 0f) 1.5f else 0f)
        return if (warnNow && (hot >= 0f || batt >= 0f || status >= 2)) 1 else 0
    }

    /** gaming = optimizations are active. */
    fun next(cpu: Float, gpu: Float, batt: Float, status: Int, prev: ThermalState, gaming: Boolean): ThermalState {
        if (!gaming) return ThermalState.NORMAL
        return when (level(cpu, gpu, batt, status, prev)) {
            2 -> ThermalState.PROTECTION
            1 -> ThermalState.WARNING
            else -> ThermalState.PERFORMANCE
        }
    }
}
