package com.sanju.systemx.game

import com.sanju.systemx.settings.Prefs

enum class GpuLevel(val label: String) { AUTO("AUTO"), BALANCED("BALANCED"), PERFORMANCE("PERFORMANCE"), MAXIMUM("MAXIMUM BEST-EFFORT") }
enum class Effect(val label: String) { DEFAULT("DEFAULT"), COOL("COOL"), VIVID("VIVID"), CINEMATIC("CINEMATIC"), PERFORMANCE("PERFORMANCE") }
enum class DnsChoice(val label: String, val host: String) {
    SYSTEM("AUTOMATIC", ""), CLOUDFLARE("CLOUDFLARE", "one.one.one.one"), GOOGLE("GOOGLE", "dns.google"), QUAD9("QUAD9", "dns.quad9.net")
}
enum class TouchMode(val label: String) { FAST("FAST"), DEFAULT("DEFAULT"), SLOW("SLOW") }

/** Everything the app needs to know about one game. New games are data, not code. */
data class GameProfile(
    val packageName: String,
    val gameName: String,
    val preferredPerformanceMode: GpuLevel = GpuLevel.AUTO,
    val preferredEffects: Effect = Effect.DEFAULT,
    val networkProfile: DnsChoice = DnsChoice.SYSTEM,
    val touchMode: TouchMode = TouchMode.DEFAULT,
    val backgroundOptimization: Boolean = false,
    val autoOptimize: Boolean = true,
    val restoreOnExit: Boolean = true
)

object GameProfiles {
    const val MLBB = "com.mobile.legends"
    private val builtin = listOf(MLBB to "Mobile Legends")

    /** (package, display name) of every known game: built-ins plus ones the user added. */
    fun list(prefs: Prefs): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>(builtin)
        for (l in prefs.getS("games_custom", "").lines()) {
            val i = l.indexOf('|')
            if (i > 0) {
                val pkg = l.substring(0, i).trim(); val nm = l.substring(i + 1).trim()
                if (pkg.isNotEmpty() && out.none { it.first == pkg }) out.add(pkg to nm.ifEmpty { pkg })
            }
        }
        return out
    }

    fun packages(prefs: Prefs): Set<String> = list(prefs).map { it.first }.toSet()

    fun add(prefs: Prefs, pkg: String, name: String): Boolean {
        if (pkg.isBlank() || list(prefs).any { it.first == pkg }) return false
        val cur = prefs.getS("games_custom", "")
        prefs.setS("games_custom", (if (cur.isEmpty()) "" else cur + "\n") + pkg + "|" + name.replace('\n', ' ').replace('|', ' '))
        return true
    }

    private inline fun <reified E : Enum<E>> en(prefs: Prefs, key: String, def: E): E =
        try { enumValueOf<E>(prefs.getS(key, def.name)) } catch (t: Throwable) { def }

    fun load(prefs: Prefs, pkg: String): GameProfile {
        val name = list(prefs).firstOrNull { it.first == pkg }?.second ?: pkg
        val k = "gp.$pkg."
        return GameProfile(
            pkg, name,
            en(prefs, k + "gpu", GpuLevel.AUTO), en(prefs, k + "fx", Effect.DEFAULT),
            en(prefs, k + "dns", DnsChoice.SYSTEM), en(prefs, k + "touch", TouchMode.DEFAULT),
            prefs.getB(k + "bg", false), prefs.getB(k + "auto", true), prefs.getB(k + "restore", true)
        )
    }

    fun save(prefs: Prefs, p: GameProfile) {
        val k = "gp.${p.packageName}."
        prefs.setS(k + "gpu", p.preferredPerformanceMode.name); prefs.setS(k + "fx", p.preferredEffects.name)
        prefs.setS(k + "dns", p.networkProfile.name); prefs.setS(k + "touch", p.touchMode.name)
        prefs.setB(k + "bg", p.backgroundOptimization); prefs.setB(k + "auto", p.autoOptimize); prefs.setB(k + "restore", p.restoreOnExit)
    }

    fun selected(prefs: Prefs): String {
        val s = prefs.getS("selected_game", MLBB)
        return if (list(prefs).any { it.first == s }) s else MLBB
    }
}

/** Display-capability driven target: 60 Hz -> ~30 FPS, 90 Hz -> ~60 FPS, 120 Hz -> ~90 FPS. 0 = unknown. */
object AutoTarget {
    fun gameFps(maxPanelHz: Int): Int = when {
        maxPanelHz >= 140 -> 120
        maxPanelHz >= 115 -> 90
        maxPanelHz >= 85 -> 60
        maxPanelHz >= 55 -> 30
        else -> 0
    }
}
