package com.sanju.systemx.network

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import com.sanju.systemx.core.St
import com.sanju.systemx.game.DnsChoice
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.optimizer.Sett
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Real network measurements + Private DNS (DNS-over-TLS) configuration through Android's own settings.
 * DNS only changes name resolution; in-match ping is measured separately and is NOT claimed to improve.
 */
object NetEngine {
    @Volatile var pingMs = -1f
    @Volatile var jitterMs = -1f
    @Volatile var lossPct = -1f
    @Volatile var dnsLookupMs = -1f
    @Volatile var source = ""
    @Volatile var anchor = ""
    @Volatile var quality = "--"
    @Volatile var seq = 0
    @Volatile var hasIcmp: Boolean? = null

    private val anchors = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9")
    private val RTT = Regex("""=\s*([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)""")
    private val LOSS = Regex("""([\d.]+)%\s*packet loss""")

    class Result(val st: St, val detail: String)

    private fun icmp(host: String, count: Int): Triple<Float, Float, Float>? {
        val r = ShizukuBridge.sh("ping -c $count -i 0.2 -W 1 -q $host 2>&1", 9000L, "PING")
        val txt = r.stdout + "\n" + r.stderr
        val loss = LOSS.find(txt)?.groupValues?.get(1)?.toFloatOrNull() ?: return null
        val m = RTT.find(txt)
        return if (m == null) Triple(-1f, -1f, loss)
        else Triple(m.groupValues[2].toFloat(), m.groupValues[4].toFloat(), loss)
    }

    private fun tcp(host: String, count: Int): Triple<Float, Float, Float> {
        val t = ArrayList<Float>(); var fail = 0
        for (i in 0 until count) {
            val s = Socket()
            val t0 = System.nanoTime()
            try { s.connect(InetSocketAddress(host, 443), 1000); t.add((System.nanoTime() - t0) / 1e6f) }
            catch (e: Throwable) { fail++ } finally { try { s.close() } catch (e: Throwable) { } }
            try { Thread.sleep(120) } catch (e: InterruptedException) { break }
        }
        if (t.isEmpty()) return Triple(-1f, -1f, 100f)
        var jit = 0f
        for (i in 1 until t.size) jit += Math.abs(t[i] - t[i - 1])
        jit = if (t.size > 1) jit / (t.size - 1) else 0f
        return Triple(t.average().toFloat(), jit, fail * 100f / count)
    }

    private fun measureOne(host: String, count: Int): Triple<Float, Float, Float> {
        if (hasIcmp != false && ShizukuBridge.state().name == "CONNECTED") {
            val r = icmp(host, count)
            if (r != null) { hasIcmp = true; source = "ICMP"; return r }
            hasIcmp = false
        }
        source = "TCP connect"
        return tcp(host, count)
    }

    /** Blocking (about 2-4 s). Call from a worker thread only. */
    fun measure(ctx: Context) {
        try {
            if (anchor.isEmpty()) {
                var best = Float.MAX_VALUE
                for (a in anchors) {
                    val r = measureOne(a, 3)
                    if (r.first >= 0f && r.first < best) { best = r.first; anchor = a }
                }
                if (anchor.isEmpty()) anchor = anchors[0]
            }
            val r = measureOne(anchor, 5)
            pingMs = if (r.first >= 0f) r.first else -1f
            jitterMs = if (r.first >= 0f) r.second else -1f
            lossPct = r.third
            val t0 = System.nanoTime()
            try { InetAddress.getByName("sx" + (System.nanoTime() % 1000000L) + ".example.com") } catch (e: Throwable) { }
            val d = (System.nanoTime() - t0) / 1e6f
            dnsLookupMs = if (d < 4000f) d else -1f
            quality = when {
                pingMs < 0f -> "OFFLINE"
                lossPct <= 0.5f && pingMs < 60f && jitterMs < 15f -> "GOOD"
                lossPct <= 2f && pingMs < 120f && jitterMs < 40f -> "FAIR"
                else -> "POOR"
            }
        } catch (t: Throwable) {
            pingMs = -1f; jitterMs = -1f; lossPct = -1f; quality = "--"
        }
        seq++
    }

    // ------------------------------------------------------------ Private DNS

    private fun linkState(ctx: Context): Pair<Boolean, String> {
        if (Build.VERSION.SDK_INT < 28) return false to ""
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val lp = cm.getLinkProperties(cm.activeNetwork)
            (lp?.isPrivateDnsActive == true) to (lp?.privateDnsServerName ?: "")
        } catch (t: Throwable) { false to "" }
    }

    fun currentDescription(ctx: Context): String {
        val mode = Sett.get("global", "private_dns_mode")
        val host = Sett.get("global", "private_dns_specifier")
        val ls = linkState(ctx)
        return when {
            mode == "hostname" -> host + (if (ls.first) "  (active)" else "  (not active)")
            mode == "off" -> "Private DNS off (network DNS)"
            else -> "Automatic" + (if (ls.first) "  (" + ls.second + ")" else "")
        }
    }

    fun apply(ctx: Context, prefs: Prefs, c: DnsChoice): Result {
        if (Build.VERSION.SDK_INT < 28) return Result(St.UNSUPPORTED, "Private DNS needs Android 9+")
        if (c == DnsChoice.SYSTEM) return Result(St.VERIFIED, "Using the system/automatic DNS (no change)")
        val ok1 = Sett.putVerified(prefs, "global", "private_dns_specifier", c.host)
        val ok2 = Sett.putVerified(prefs, "global", "private_dns_mode", "hostname")
        if (!ok1 || !ok2) return Result(St.FAILED, "Android refused the Private DNS settings")
        for (i in 0 until 8) {
            val ls = linkState(ctx)
            if (ls.first && ls.second.equals(c.host, true)) return Result(St.VERIFIED, c.label + " Private DNS active on the current network")
            try { Thread.sleep(500) } catch (e: InterruptedException) { break }
        }
        return Result(St.FAILED, "Setting saved but Private DNS is not active (this network may block DNS-over-TLS on port 853)")
    }
}
