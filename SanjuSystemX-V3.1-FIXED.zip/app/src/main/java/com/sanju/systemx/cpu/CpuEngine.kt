package com.sanju.systemx.cpu

import android.os.Build
import com.sanju.systemx.core.St
import com.sanju.systemx.optimizer.Journal
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

class CpuPolicy(val name: String, val cpus: String, val minKhz: Long, val maxKhz: Long, val governor: String)

class CpuInfo(
    val abi: String, val hardware: String, val platform: String, val cores: Int,
    val policies: List<CpuPolicy>, val fixedPerfCommand: Boolean
)

/**
 * CPU capability + safe performance hint. No cpufreq/governor writes are made: the only control used is Android's own
 * PowerManager "fixed performance mode" (cmd power), which the device's Power HAL may or may not honour.
 */
object CpuEngine {
    class Result(val st: St, val detail: String)

    fun probe(): CpuInfo {
        val script = """
echo "CORES=§(ls -d /sys/devices/system/cpu/cpu[0-9]* 2>/dev/null | wc -l)"
echo "PLAT=§(getprop ro.board.platform)"
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "§p" ] || continue
  echo "POL=§(basename §p)|§(cat §p/related_cpus 2>/dev/null)|§(cat §p/cpuinfo_min_freq 2>/dev/null)|§(cat §p/cpuinfo_max_freq 2>/dev/null)|§(cat §p/scaling_governor 2>/dev/null)"
done
echo "FIXED=§(cmd power 2>&1 | grep -c 'set-fixed-performance-mode-enabled')"
""".replace('§', '$')
        val r = ShizukuBridge.sh(script, 8000L, "CPU_PROBE")
        var cores = 0; var plat = ""; var fixed = false
        val pol = ArrayList<CpuPolicy>()
        for (l in r.stdout.lines()) {
            val i = l.indexOf('=')
            if (i <= 0) continue
            val k = l.substring(0, i); val v = l.substring(i + 1).trim()
            when (k) {
                "CORES" -> cores = v.toIntOrNull() ?: 0
                "PLAT" -> plat = v
                "FIXED" -> fixed = (v.toIntOrNull() ?: 0) > 0
                "POL" -> {
                    val p = v.split('|')
                    if (p.size >= 5) pol.add(CpuPolicy(p[0], p[1].trim(), p[2].toLongOrNull() ?: -1L, p[3].toLongOrNull() ?: -1L, p[4]))
                }
            }
        }
        if (cores == 0) cores = Runtime.getRuntime().availableProcessors()
        return CpuInfo(Build.SUPPORTED_ABIS.firstOrNull() ?: "?", Build.HARDWARE, plat, cores, pol, fixed && Build.VERSION.SDK_INT >= 31)
    }

    fun describe(i: CpuInfo?): String {
        if (i == null) return "--"
        val cl = if (i.policies.isEmpty()) "" else "  " + i.policies.size + " clusters"
        return i.abi + "  " + i.cores + " cores" + cl
    }

    /** Fixed-performance hint. Reported APPLIED (accepted) unless the power service dump confirms it. */
    fun applyPerformanceHint(prefs: Prefs, info: CpuInfo?): Result {
        if (info == null || !info.fixedPerfCommand) return Result(St.UNSUPPORTED, "No PowerManager performance command on this Android version")
        Journal.saveOnce(prefs, "power.fixed", "0")
        val r = ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled true 2>&1", 4000L, "CPU_PERFORMANCE")
        val bad = r.out.contains("error", true) || r.out.contains("unknown", true) || r.out.contains("exception", true)
        if (!r.success || bad) return Result(St.FAILED, "System rejected it: " + r.out.take(60))
        val dump = ShizukuBridge.sh("dumpsys power 2>/dev/null | grep -i -m3 'fixed.*perf'", 5000L, "CPU_PERFORMANCE").stdout.lowercase()
        return if (dump.contains("true") || dump.contains("enabled=1") || dump.contains("= 1"))
            Result(St.VERIFIED, "Fixed performance mode confirmed by PowerManager")
        else Result(St.APPLIED, "Accepted by PowerManager (the Power HAL gives no read-back)")
    }

    fun releasePerformanceHint(): Boolean =
        ShizukuBridge.sh("cmd power set-fixed-performance-mode-enabled false 2>&1", 4000L, "CPU_PERFORMANCE").success
}
