package com.sanju.systemx.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import com.sanju.systemx.core.Cap
import com.sanju.systemx.core.CapabilityEngine
import com.sanju.systemx.core.Capability
import com.sanju.systemx.core.Caps
import com.sanju.systemx.core.Features
import com.sanju.systemx.core.St
import com.sanju.systemx.cpu.CpuEngine
import com.sanju.systemx.effects.EffectsEngine
import com.sanju.systemx.game.AutoTarget
import com.sanju.systemx.game.GameProfile
import com.sanju.systemx.game.GameProfiles
import com.sanju.systemx.game.GpuLevel
import com.sanju.systemx.gpu.GpuEngine
import com.sanju.systemx.monitor.Calc
import com.sanju.systemx.monitor.FrameStats
import com.sanju.systemx.monitor.Raw
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.network.NetEngine
import com.sanju.systemx.optimizer.Applier
import com.sanju.systemx.optimizer.BgOptimizer
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.thermal.ThermalGuard
import com.sanju.systemx.thermal.ThermalState
import com.sanju.systemx.touch.TouchCtl
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * SANJU AUTO GAME MODE engine. One background thread runs:
 * DETECT (game, display, CPU, GPU, thermal, network) -> APPLY -> VERIFY -> MONITOR -> ADJUST -> RESTORE.
 * The UI only reads the @Volatile fields. Metrics that cannot be read stay at -1 and the UI shows "--".
 */
object Engine {
    private var app: Context? = null
    private var prefs: Prefs? = null
    private var ht: HandlerThread? = null
    private var h: Handler? = null
    private val calc = Calc()
    val frames = FrameStats()
    private val netExec = Executors.newSingleThreadExecutor()

    @Volatile var uiVisible = false
    @Volatile var watcherActive = false
    @Volatile var screenOn = true

    // ---- state read by the UI ----
    @Volatile var shizuku = ShizukuState.DISCONNECTED
    @Volatile var gameFg = false
    @Volatile var fgKnown = true
    @Volatile var fgPkg = ""
    @Volatile var profile: GameProfile? = null
    @Volatile var fpsSource = ""
    @Volatile var fpsNote = ""
    @Volatile var hzActual = -1f
    @Volatile var hzMax = -1
    @Volatile var hzTarget = 0
    @Volatile var targetFps = 0
    @Volatile var cpuPct = -1f
    @Volatile var cpuMhz = -1
    @Volatile var cpuClusters = ""
    @Volatile var cpuTemp = -1f
    @Volatile var gpuPct = -1f
    @Volatile var gpuMhz = -1
    @Volatile var gpuTemp = -1f
    @Volatile var battTemp = -1f
    @Volatile var thermal = ThermalState.NORMAL
    @Volatile var thermalStatus = -1
    @Volatile var applied = false
    @Volatile var appliedBy = ""
    @Volatile var busy = false
    @Volatile var sampleSeq = 0
    @Volatile var lastSummary = ""

    private var layers: List<String> = emptyList()
    private var layerIdx = 0
    private var layerAt = 0L
    private var noNew = 0
    private var sfEmpty = 0
    private var miss = 0
    private var fgBlank = 0
    private var cycle = 0L
    private var needRecovery = true
    private var wasConnected = false
    private var fpsSeen = false
    private var reassert = 0
    private var wantGpu = GpuLevel.AUTO
    private var released = false
    private var netAt = 0L
    @Volatile private var netBusy = false
    private val logBuf = ArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun init(ctx: Context) {
        if (h != null) return
        app = ctx.applicationContext
        prefs = Prefs.get(ctx)
        ShizukuBridge.init()
        val t = HandlerThread("sx-engine")
        t.start()
        ht = t
        h = Handler(t.looper)
        ShizukuBridge.addStateListener { kick() }
        try {
            val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
            f.addAction(Intent.ACTION_SCREEN_ON)
            app?.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    screenOn = i?.action != Intent.ACTION_SCREEN_OFF
                    log(if (screenOn) "SCREEN ON" else "SCREEN OFF")
                    kick()
                }
            }, f)
        } catch (e: Throwable) { }
        log("ENGINE STARTED")
        kick()
    }

    private val tickRun = object : Runnable {
        override fun run() {
            val next = try { tick() } catch (t: Throwable) { log("ENGINE ERROR: " + (t.message ?: t.javaClass.simpleName)); 3000L }
            h?.postDelayed(this, next)
        }
    }

    /** Run a tick as soon as possible. */
    fun kick() {
        val hh = h ?: return
        hh.removeCallbacks(tickRun)
        hh.post(tickRun)
    }

    fun log(msg: String) {
        synchronized(logBuf) {
            logBuf.add(timeFmt.format(Date()) + "  " + msg)
            while (logBuf.size > 60) logBuf.removeAt(0)
        }
    }

    fun logTail(n: Int): List<String> = synchronized(logBuf) { logBuf.takeLast(n) }

    private fun sfx(s: Sfx) { if (uiVisible || prefs?.getB("sfx_in_game", false) == true) SfxHub.play(s) }

    // ---------------------------------------------------------------- UI actions

    fun applyNow() { h?.post { applyProfile(false) } }
    fun restoreNow() { h?.post { doRestore("MANUAL RESTORE") } }
    fun redetect() { h?.post { CapabilityEngine.detected = false }; kick() }
    fun measureNetNow() { netAt = 0L; kick() }

    /** Re-reads the real panel against the last requested refresh rate. */
    fun reverifyDisplay() {
        h?.post {
            val ctx = app ?: return@post
            if (hzTarget <= 0) { log("DISPLAY: no refresh-rate request is active"); return@post }
            val v = DisplayCtl.verify(ctx, hzTarget)
            Features.set(Features.DISPLAY, v.first, v.second)
            log("DISPLAY: " + v.second)
        }
    }

    /** Called when the user edits a game profile. Only the changed feature is re-applied while a game is running. */
    fun profileChanged(what: String) {
        h?.post {
            val p = prefs ?: return@post
            val prof = GameProfiles.load(p, activePkgOrSelected())
            profile = prof
            if (!gameFg || shizuku != ShizukuState.CONNECTED) return@post
            if (what == "none") return@post
            if (!applied) { if (p.getB("auto_mode", true) && prof.autoOptimize) applyProfile(true); return@post }
            val ctx = app ?: return@post
            when (what) {
                "fx" -> { val r = EffectsEngine.apply(p, prof.preferredEffects); Features.set(Features.EFFECT, r.st, prof.preferredEffects.label + ": " + r.detail); log("EFFECT: " + r.detail) }
                "dns" -> {
                    Applier.restoreKeys(p, listOf("set.global.private_dns_mode", "set.global.private_dns_specifier"))
                    val r = NetEngine.apply(ctx, p, prof.networkProfile); Features.set(Features.DNS, r.st, r.detail); log("DNS: " + r.detail)
                }
                "touch" -> { val r = TouchCtl.apply(p, prof.touchMode); Features.set(Features.TOUCH, r.st, r.detail); log("TOUCH: " + r.detail) }
                "gpu" -> { wantGpu = prof.preferredPerformanceMode; if (thermal != ThermalState.PROTECTION) Applier.applyGpu(p, wantGpu) { log(it) } }
                "bg" -> if (prof.backgroundOptimization) { val r = BgOptimizer.run(ctx, p, prof.packageName); Features.set(Features.BG, r.st, r.detail); log("BACKGROUND: " + r.detail) }
                    else Features.set(Features.BG, St.IDLE, "Off for this game")
                "none" -> { }
                else -> { doRestore("PROFILE CHANGED"); applyProfile(true) }
            }
        }
    }

    fun addCurrentAsGame(): String {
        val p = prefs ?: return "Engine not ready"
        val pkg = fgPkg
        val ctx = app ?: return "Engine not ready"
        if (pkg.isEmpty() || pkg == ctx.packageName) return "Open the game first, then return here"
        if (GameProfiles.list(p).any { it.first == pkg }) return "Already in the game list"
        val label = try { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (t: Throwable) { pkg }
        GameProfiles.add(p, pkg, label)
        log("GAME ADDED: $label")
        return "Added $label"
    }

    private fun activePkgOrSelected(): String = profile?.packageName?.takeIf { gameFg } ?: GameProfiles.selected(prefs!!)

    // ---------------------------------------------------------------- main loop

    private fun tick(): Long {
        val ctx = app ?: return 5000L
        val p = prefs ?: return 5000L
        shizuku = ShizukuBridge.state()
        hzActual = DisplayCtl.current(ctx)
        hzMax = DisplayCtl.maxRate(ctx)
        targetFps = AutoTarget.gameFps(hzMax)
        battTemp = batteryTemp(ctx)
        maybeNet(ctx)

        if (shizuku != ShizukuState.CONNECTED) {
            if (wasConnected) { wasConnected = false; log("SHIZUKU LOST: monitoring paused, restore is kept in the journal") ; sfx(Sfx.WARNING) }
            cpuPct = -1f; cpuMhz = -1; cpuTemp = -1f; gpuPct = -1f; gpuMhz = -1; gpuTemp = -1f; cpuClusters = ""
            frames.reset(); calc.resetCpu()
            gameFg = false
            return if (uiVisible) 1500L else 8000L
        }
        if (!wasConnected) {
            wasConnected = true
            needRecovery = true      // on (re)connect: restore leftovers if no game is running, or re-apply if one is
            log("SHIZUKU CONNECTED (" + ShizukuBridge.privilegeLabel() + ")")
        }
        if (!uiVisible && !watcherActive && !gameFg) return 20000L

        if (!CapabilityEngine.detected) {
            busy = true
            CapabilityEngine.detect(ctx, fpsSeen)
            busy = false
            log("CAPABILITIES DETECTED: " + Caps.list.count { it.controllable } + " controllable of " + Caps.list.size)
        }

        cycle++
        val full = (uiVisible || gameFg) && screenOn
        if (!full) {
            val raw = Sampler.sampleFg()
            evalFg(raw?.fg)
            return if (screenOn) 3000L else 5000L
        }
        val checkFg = !gameFg || cycle % 3L == 0L
        if (gameFg && layers.isEmpty() && SystemClock.uptimeMillis() - layerAt > 4000L) discoverLayers()
        val layer = if (gameFg && layers.isNotEmpty()) layers[layerIdx % layers.size] else ""
        val raw = Sampler.sampleFull(CapabilityEngine.gpu?.dir ?: "", layer, checkFg)
        if (raw == null) return 1500L
        updateMetrics(raw)
        evalFg(raw.fg)
        if (gameFg && applied) adjust(p, ctx)
        sampleSeq++
        return 1000L
    }

    private fun updateMetrics(raw: Raw) {
        cpuPct = calc.cpu(raw.stat)
        val mx = raw.freqs.maxOrNull()
        cpuMhz = if (mx == null) -1 else (mx / 1000L).toInt()
        cpuClusters = raw.clusters.joinToString("  ") { (it.first / 1000L).toString() }
        var ct = -1f; var gt = -1f
        for ((id, tv) in raw.temps) {
            val type = raw.types[id] ?: continue
            val t = Sampler.normTemp(tv)
            if (t < -20f || t > 150f) continue
            if (Sampler.isGpuZone(type)) { if (t > gt) gt = t }
            else if (Sampler.isCpuZone(type)) { if (t > ct) ct = t }
        }
        cpuTemp = ct; gpuTemp = gt
        val gf = raw.gpuF?.trim()?.toLongOrNull()
        gpuMhz = if (gf == null) -1 else GpuEngine.toMhz(gf)
        gpuPct = Sampler.gpuBusy(raw.gpuB)

        if (!gameFg) { fpsNote = ""; return }
        val now = SystemClock.uptimeMillis()
        val pkg = profile?.packageName ?: return
        val stamps = Sampler.sfStamps(raw.fps)
        var n = frames.feed(stamps, now)
        fpsSource = if (stamps.isNotEmpty()) "SurfaceFlinger frame timing" else fpsSource
        sfEmpty = if (stamps.isEmpty()) sfEmpty + 1 else 0
        if (sfEmpty >= 3 && cycle % 2L == 0L) {
            val g = Sampler.fetchGfxStamps(pkg)
            if (g.isNotEmpty()) { n += frames.feed(g, now); fpsSource = "gfxinfo frame stats" }
        }
        if (n > 0) { noNew = 0; fpsNote = ""; if (!fpsSeen) { fpsSeen = true; markFpsVerified() } }
        else {
            noNew++
            fpsNote = if (sfEmpty >= 4) "No frame data is exposed for this game on this device" else "Waiting for new frames"
            if (noNew >= 3 && layers.size > 1) { layerIdx++; noNew = 0 }
        }
    }

    private fun markFpsVerified() {
        Caps.list = Caps.list.map {
            if (it.name == Cap.FPS_MON) Capability(it.name, true, false, true, "Frame data received (" + fpsSource + ")", it.backend) else it
        }
    }

    private fun discoverLayers() {
        layerAt = SystemClock.uptimeMillis()
        val pkg = profile?.packageName ?: return
        layers = Sampler.discoverLayers(pkg)
        layerIdx = 0
        if (layers.isNotEmpty()) log("FPS source layer: " + layers[0].take(48))
    }

    private fun parseFgPkg(txt: String): String? {
        val m = Regex("""\bu\d+\s+([A-Za-z0-9_.]+)/""").find(txt) ?: Regex("""\s([A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+)/""").find(txt)
        return m?.groupValues?.get(1)
    }

    private fun evalFg(txt: String?) {
        if (txt == null) return
        val p = prefs ?: return
        if (txt.isBlank()) {
            fgBlank++
            if (fgBlank >= 5) fgKnown = false
            return
        }
        fgBlank = 0
        fgKnown = true
        parseFgPkg(txt)?.let { fgPkg = it }
        val hit = GameProfiles.packages(p).firstOrNull { txt.contains(it) }
        if (hit != null) {
            miss = 0
            if (!gameFg || profile?.packageName != hit) { if (gameFg) onGameStop(); onGameStart(hit) }
        } else {
            if (gameFg) {
                miss++
                if (miss >= 2) onGameStop()
            } else if (needRecovery && !applied && Applier.hasJournal(p)) {
                doRestore("RECOVERY")
            }
        }
        needRecovery = false
    }

    // ---------------------------------------------------------------- game lifecycle

    private fun onGameStart(pkg: String) {
        val p = prefs ?: return
        val prof = GameProfiles.load(p, pkg)
        profile = prof
        gameFg = true
        miss = 0; noNew = 0; sfEmpty = 0; layers = emptyList(); layerIdx = 0; layerAt = 0L; reassert = 0
        frames.reset()
        log("GAME DETECTED: " + prof.gameName)
        sfx(Sfx.GAME_DETECTED)
        if (p.getB("auto_mode", true) && prof.autoOptimize) {
            if (applied) log("ALREADY OPTIMIZED") else applyProfile(true)
        } else log("AUTO MODE OFF: monitoring only")
        kick()
    }

    private fun onGameStop() {
        val prof = profile
        gameFg = false
        miss = 0
        frames.reset()
        log("GAME CLOSED" + (prof?.let { ": " + it.gameName } ?: ""))
        if (applied && appliedBy == "AUTO" && (prof?.restoreOnExit != false)) doRestore("GAME EXITED")
    }

    private fun applyProfile(auto: Boolean) {
        val ctx = app ?: return
        val p = prefs ?: return
        if (shizuku != ShizukuState.CONNECTED) { log("SHIZUKU REQUIRED: nothing applied"); return }
        val prof = profile ?: GameProfiles.load(p, GameProfiles.selected(p))
        profile = prof
        busy = true
        log("SANJU AUTO: optimizing " + prof.gameName + " (target " + AutoTarget.gameFps(DisplayCtl.maxRate(ctx)) + " FPS for a " + DisplayCtl.maxRate(ctx) + " Hz panel)")
        sfx(Sfx.BOOST_ON)
        val s = try { Applier.apply(ctx, p, prof) { log(it) } } catch (t: Throwable) { log("APPLY ERROR: " + (t.message ?: "")); busy = false; return }
        hzTarget = s.targetHz
        wantGpu = prof.preferredPerformanceMode
        released = false; reassert = 0
        applied = true
        appliedBy = if (auto) "AUTO" else "MANUAL"
        thermal = ThermalState.PERFORMANCE
        lastSummary = s.verified.toString() + " verified, " + s.applied + " applied, " + s.failed + " failed, " + s.unsupported + " unsupported"
        log("RESULT: $lastSummary")
        busy = false
        sfx(if (s.failed == 0 && s.verified + s.applied > 0) Sfx.OPTIMIZE_DONE else Sfx.WARNING)
    }

    private fun doRestore(reason: String) {
        val p = prefs ?: return
        busy = true
        log("$reason: RESTORING")
        val lines = try { Applier.restore(p) } catch (t: Throwable) { listOf("RESTORE ERROR: " + (t.message ?: "")) }
        for (l in lines) if (!l.startsWith("RESTORED")) log(l)
        val failed = lines.count { it.startsWith("RESTORE FAILED") }
        log(if (failed == 0) "RESTORE COMPLETE (" + lines.count { it.startsWith("RESTORED") } + " items)" else "RESTORE INCOMPLETE: $failed items will be retried")
        applied = false
        appliedBy = ""
        thermal = ThermalState.NORMAL
        hzTarget = 0
        Features.clear()
        busy = false
        if (lines.any { it.startsWith("RESTORED") }) sfx(Sfx.SUCCESS)
    }

    // ---------------------------------------------------------------- dynamic adjustment

    private fun adjust(p: Prefs, ctx: Context) {
        if (cycle % 5L == 0L) {
            val r = ShizukuBridge.sh("dumpsys thermalservice 2>/dev/null | grep -m1 -i 'Thermal Status'", 5000L, "THERMAL")
            val m = Regex("""(\d+)\s*$""").find(r.stdout.trim())
            thermalStatus = m?.groupValues?.get(1)?.toIntOrNull() ?: -1
        }
        val prev = thermal
        val next = ThermalGuard.next(cpuTemp, gpuTemp, battTemp, thermalStatus, prev, true)
        if (next != prev) {
            thermal = next
            log("THERMAL: " + prev.label + " -> " + next.label)
            when (next) {
                ThermalState.PROTECTION -> {
                    GpuEngine.release(p); CpuEngine.releasePerformanceHint(); released = true
                    Features.set(Features.GPU, St.IDLE, "Released for thermal protection")
                    sfx(Sfx.WARNING)
                }
                ThermalState.WARNING -> {
                    if (wantGpu != GpuLevel.BALANCED && !released) Applier.applyGpu(p, GpuLevel.BALANCED) { log(it) }
                    else if (released) { Applier.applyGpu(p, GpuLevel.BALANCED) { log(it) }; released = false }
                    sfx(Sfx.WARNING)
                }
                ThermalState.PERFORMANCE, ThermalState.NORMAL -> {
                    Applier.applyGpu(p, wantGpu) { log(it) }
                    if (released) { CpuEngine.applyPerformanceHint(p, CapabilityEngine.cpu); released = false }
                }
            }
        }
        // some vendors reset the refresh rate: re-assert up to 3 times, verified against the real panel
        if (cycle % 15L == 0L && hzTarget > 0 && reassert < 3 && Features.get(Features.DISPLAY).st == St.VERIFIED && hzActual < hzTarget - 1.5f) {
            reassert++
            log("DISPLAY dropped to " + Math.round(hzActual) + " Hz, re-requesting " + hzTarget + " Hz")
            val r = DisplayCtl.request(ctx, p)
            if (r.state == St.REQUESTED) { val v = DisplayCtl.verify(ctx, hzTarget); Features.set(Features.DISPLAY, v.first, v.second) }
        }
    }

    // ---------------------------------------------------------------- network sampling

    private fun maybeNet(ctx: Context) {
        val now = SystemClock.uptimeMillis()
        if (netBusy || !(uiVisible || gameFg) || !screenOn || now - netAt < 8000L) return
        netBusy = true
        netAt = now
        netExec.execute { try { NetEngine.measure(ctx) } finally { netBusy = false } }
    }

    private fun batteryTemp(ctx: Context): Float {
        return try {
            val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (t < 0) -1f else t / 10f
        } catch (e: Throwable) { -1f }
    }
}
