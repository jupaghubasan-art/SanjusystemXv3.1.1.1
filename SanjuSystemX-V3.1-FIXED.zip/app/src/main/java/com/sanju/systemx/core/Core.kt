package com.sanju.systemx.core

import java.util.concurrent.ConcurrentHashMap

/** The five honest states the UI may show for any operation (plus IDLE when nothing was asked). */
enum class St(val label: String) {
    IDLE("IDLE"), REQUESTED("REQUESTED"), APPLIED("APPLIED"), VERIFIED("VERIFIED"), FAILED("FAILED"), UNSUPPORTED("UNSUPPORTED")
}

class FeatureState(val st: St, val detail: String)

/** Live status of every feature, read by the UI. Written only by the engine/appliers. */
object Features {
    const val PERF = "PERF"        // game mode + CPU performance hint
    const val DISPLAY = "DISPLAY"  // refresh rate
    const val GPU = "GPU"
    const val EFFECT = "EFFECT"
    const val DNS = "DNS"
    const val TOUCH = "TOUCH"
    const val BG = "BG"
    const val FPSCAP = "FPSCAP"    // game-mode FPS intervention

    private val map = ConcurrentHashMap<String, FeatureState>()
    fun set(name: String, st: St, detail: String = "") { map[name] = FeatureState(st, detail) }
    fun get(name: String): FeatureState = map[name] ?: FeatureState(St.IDLE, "")
    fun clear() { map.clear() }
}

/** One detected capability of this device. */
class Capability(
    val name: String,
    val supported: Boolean,
    val controllable: Boolean,
    val verified: Boolean,
    val reason: String,
    val backend: String
)

object Cap {
    const val SHIZUKU = "SHIZUKU"
    const val DISPLAY_HIGH_HZ = "DISPLAY_HIGH_HZ"
    const val GAME_MODE = "GAME_MODE"
    const val GAME_FPS = "GAME_FPS_OVERRIDE"
    const val GPU_PERF = "GPU_PERFORMANCE"
    const val GPU_MON = "GPU_MONITOR"
    const val CPU_PERF = "CPU_PERFORMANCE"
    const val CPU_MON = "CPU_MONITOR"
    const val THERMAL = "THERMAL"
    const val TOUCH = "TOUCH_RESPONSE"
    const val COLOR = "DISPLAY_COLOR"
    const val DNS = "DNS"
    const val PING = "PING"
    const val FPS_MON = "FPS_MONITOR"
    const val BG = "BACKGROUND_OPT"
}

object Caps {
    @Volatile var list: List<Capability> = emptyList()
    fun get(name: String): Capability? = list.firstOrNull { it.name == name }
    fun controllable(name: String): Boolean = get(name)?.controllable == true
    fun supported(name: String): Boolean = get(name)?.supported == true
}
