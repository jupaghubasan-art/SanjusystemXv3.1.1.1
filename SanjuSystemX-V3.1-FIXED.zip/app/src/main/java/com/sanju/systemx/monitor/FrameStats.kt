package com.sanju.systemx.monitor

/**
 * Real frame statistics from presentation timestamps (nanoseconds). Frames are de-duplicated across samples, so every
 * number comes from frames that were actually presented. Anything not yet measurable stays -1 (shown as "--").
 */
class FrameStats {
    private var lastTs = 0L
    private var lastNewAt = 0L
    private val win = ArrayList<Long>()
    private val iv = ArrayList<Float>()      // frame intervals in ms, newest last
    private val MAXIV = 1800

    @Volatile var fps = -1f
        private set        // frames per second over the last second
    @Volatile var avg = -1f
        private set        // average over the recent window
    @Volatile var low1 = -1f
        private set       // 1% low (needs >= 100 frames)
    @Volatile var frameMs = -1f
        private set    // latest frame time
    @Volatile var jankPct = -1f
        private set    // share of frames > 2x the median frame time
    @Volatile var total = 0L
        private set

    fun reset() {
        lastTs = 0L; lastNewAt = 0L; win.clear(); iv.clear()
        fps = -1f; avg = -1f; low1 = -1f; frameMs = -1f; jankPct = -1f; total = 0L
    }

    /** Returns how many genuinely new frames were added. */
    fun feed(stamps: List<Long>, nowMs: Long): Int {
        var added = 0
        for (t in stamps.sorted()) {
            if (t <= lastTs) continue
            if (lastTs > 0L) {
                val ms = (t - lastTs) / 1_000_000f
                if (ms > 0f && ms < 500f) { iv.add(ms); if (iv.size > MAXIV) iv.removeAt(0) }
            }
            lastTs = t
            win.add(t)
            added++
            total++
        }
        if (added > 0) lastNewAt = nowMs
        if (win.isNotEmpty()) {
            val cut = lastTs - 1_500_000_000L
            while (win.isNotEmpty() && win[0] < cut) win.removeAt(0)
        }
        if (added == 0) {
            if (lastNewAt > 0L && nowMs - lastNewAt > 1500L) { fps = 0f; frameMs = -1f }
            return 0
        }
        val one = win.filter { it > lastTs - 1_000_000_000L }
        if (one.size >= 2) {
            val span = one[one.size - 1] - one[0]
            if (span > 0L) fps = (one.size - 1) * 1_000_000_000f / span
        }
        if (iv.isNotEmpty()) frameMs = iv[iv.size - 1]
        recompute()
        return added
    }

    private fun recompute() {
        val n = iv.size
        if (n < 10) return
        avg = 1000f / (iv.sum() / n)
        if (n >= 100) {
            val sorted = iv.sortedDescending()
            val k = maxOf(1, n / 100)
            low1 = 1000f / (sorted.take(k).sum() / k)
        }
        if (n >= 60) {
            val med = iv.sorted()[n / 2]
            var j = 0
            for (v in iv) if (v > med * 2f && v > 20f) j++
            jankPct = j * 100f / n
        }
    }
}
