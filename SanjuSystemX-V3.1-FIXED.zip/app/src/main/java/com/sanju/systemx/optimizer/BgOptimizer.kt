package com.sanju.systemx.optimizer

import android.content.Context
import android.content.Intent
import com.sanju.systemx.core.St
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

/**
 * GAME MODE BACKGROUND OPTIMIZATION. Replaces the old blunt "am kill-all".
 * Only third-party (user-installed) apps that currently have a process are touched, and only through `am kill`, which
 * Android applies to background processes only. System apps, the launcher, keyboard, accessibility services, voice-chat /
 * messaging apps in the whitelist, Shizuku, this app and the game are never touched. Nothing persistent is changed, so it
 * is fully reversible: Android restarts apps normally when they are needed.
 */
object BgOptimizer {
    class Result(val st: St, val detail: String)

    /** Default protected apps (calls, voice chat, messaging). The user list is stored in prefs "bg_whitelist" (one package per line). */
    private val DEFAULT_KEEP = listOf(
        "com.whatsapp", "org.telegram.messenger", "com.discord", "com.facebook.orca",
        "com.spotify.music", "com.google.android.apps.maps"
    )
    private val PKG_RE = Regex("[A-Za-z0-9_.]+")

    private fun launcherPkg(ctx: Context): String? = try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        ctx.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName
    } catch (t: Throwable) { null }

    fun whitelist(ctx: Context, prefs: Prefs, gamePkg: String): Set<String> {
        val s = HashSet<String>()
        s.add(ctx.packageName); s.add(gamePkg); s.add(ShizukuBridge.PKG)
        s.addAll(DEFAULT_KEEP)
        launcherPkg(ctx)?.let { s.add(it) }
        val ime = Sett.get("secure", "default_input_method")
        if (ime != "null") s.add(ime.substringBefore('/'))
        val acc = Sett.get("secure", "enabled_accessibility_services")
        if (acc != "null") for (c in acc.split(':')) s.add(c.substringBefore('/'))
        for (l in prefs.getS("bg_whitelist", "").lines()) if (l.isNotBlank()) s.add(l.trim())
        return s
    }

    private fun running(candidates: List<String>): List<String> {
        val ps = ShizukuBridge.sh("ps -A -o NAME 2>/dev/null", 6000L, "BACKGROUND_OPT").stdout.lines().map { it.trim() }
        if (ps.size < 2) return emptyList()
        return candidates.filter { pkg -> ps.any { it == pkg || it.startsWith("$pkg:") } }
    }

    fun run(ctx: Context, prefs: Prefs, gamePkg: String): Result {
        val keep = whitelist(ctx, prefs, gamePkg)
        val third = ShizukuBridge.sh("pm list packages -3 2>/dev/null", 8000L, "BACKGROUND_OPT").stdout.lines()
            .map { it.trim().removePrefix("package:") }
            .filter { it.isNotEmpty() && PKG_RE.matches(it) && it !in keep }
        if (third.isEmpty()) return Result(St.UNSUPPORTED, "Could not list user apps")
        val before = running(third)
        if (before.isEmpty()) return Result(St.VERIFIED, "No unprotected background user apps running (${keep.size} protected)")
        ShizukuBridge.sh(before.joinToString("; ") { "am kill $it" }, 15000L, "BACKGROUND_OPT")
        val after = running(before)
        val freed = before.size - after.size
        return when {
            freed > 0 -> Result(St.VERIFIED, "Released $freed of ${before.size} background apps (${after.size} kept by Android, ${keep.size} protected)")
            else -> Result(St.FAILED, "Android kept all ${before.size} background apps (they were not safe to kill)")
        }
    }
}
